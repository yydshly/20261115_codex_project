// CPU validation of actual glTF data and scene geometry; it does not claim GPU visual QA.
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import * as THREE from 'three';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
import { loadModelLibrary, createModelCottage, createModelGarden } from './model-assets.js';
import { createMountains } from './mountains.js';
import { createStream } from './stream.js';
import { createModelWoodland } from './woodland.js';
import { riverX, riverWidth, heightAt, seededRandom } from './landscape.js';

const originalFetch=globalThis.fetch;
globalThis.fetch=async (request,options)=>{
  const url=typeof request==='string'?request:request instanceof URL?request.href:request.url;
  if(url.startsWith('file:')){
    const bytes=await readFile(new URL(url));return new Response(bytes,{headers:{'Content-Length':String(bytes.length)}});
  }
  return originalFetch(request,options);
};
globalThis.ProgressEvent=class extends Event{constructor(type,details){super(type);Object.assign(this,details);}};
THREE.TextureLoader.prototype.loadAsync=async()=>new THREE.Texture();
GLTFLoader.prototype.loadAsync=async function(url){
  this.register(()=>({name:'CPUAssetInspection',loadTexture:async()=>new THREE.Texture()}));
  const bytes=await readFile(new URL(url));
  return this.parseAsync(bytes.buffer.slice(bytes.byteOffset,bytes.byteOffset+bytes.byteLength),new URL('.',url).href);
};
const renderer={capabilities:{getMaxAnisotropy:()=>8}};
const models=await loadModelLibrary(renderer);
for(const [name,variants] of Object.entries(models))for(const variant of variants){
  assert(variant.size.y>0&&Number.isFinite(variant.size.y),`${name} has invalid height`);
  for(const part of variant.parts)for(const attr of Object.values(part.geometry.attributes)){
    assert(attr.array.every(Number.isFinite),`${name} contains non-finite vertex data`);
  }
}
const scene=new THREE.Scene();
for(const style of ['townhouse','house','cottage']){
  const house=createModelCottage(scene,models,style);
  const collider=house.colliders[0];
  assert(collider.minX<0&&collider.maxX>0&&collider.minZ<collider.maxZ);
  assert(collider.maxZ< -3,`${style} blocks the garden spawn`);
  console.log(`${style}: size ${models[style][0].size.toArray().map(x=>x.toFixed(3)).join(' × ')}, wall collider ${JSON.stringify(collider)}`);
}
const garden=createModelGarden(scene,models,{heightAt,riverX,riverWidth,random:seededRandom(5044)});
const scanCount=name=>garden.group.children.filter(o=>o.isInstancedMesh&&o.name.includes(name)).reduce((sum,o)=>sum+o.count,0);
assert(scanCount('shrub_02')>=50,'Mature model borders are missing');
assert(scanCount('flower_gazania')>=140,'Low flowering model borders are missing');
for(const mesh of garden.group.children)if(mesh.isInstancedMesh)assert(mesh.instanceMatrix.array.every(Number.isFinite));
console.log(`OK: planted ${scanCount('shrub_02')} mature shrub and ${scanCount('flower_gazania')} Gazania model instances`);
const woodland=createModelWoodland(scene,models,{heightAt,riverX,random:seededRandom(8266)});
const camera=new THREE.PerspectiveCamera();camera.position.set(0,1.8,2);
woodland.update(1,camera);
const levelCounts=()=>[0,1,2].map(level=>woodland.group.children.find(m=>m.name.startsWith(`Mature tree LOD ${level}`)).count);
let levels=levelCounts();assert.equal(levels.reduce((a,b)=>a+b,0),woodland.treeCount);
assert(levels[0]<=6&&levels[1]<=22&&levels[0]>0);
const parts=models.matureNear[0].parts,leaves=parts.find(p=>/leaves/.test(p.material.name));
assert(models.matureNear[0].size.equals(models.matureFar[0].size));
assert(models.matureNear[0].size.equals(models.matureDistant[0].size));
assert.equal(models.matureNear[0].triangles,266394);
assert.equal(models.matureFar[0].triangles,67621);
assert.equal(models.matureDistant[0].triangles,9919);
assert(leaves.material.alphaMap&&leaves.material.alphaTest>0);
assert(parts.filter(p=>!/leaves/.test(p.material.name)).every(p=>!p.material.alphaMap),'Bark must remain opaque');
assert.equal(models.matureFar[0].parts[0].material,models.matureNear[0].parts[0].material,'Tree LODs should share materials');
camera.position.set(1000,20,1000);woodland.update(2,camera);levels=levelCounts();
assert.deepEqual(levels,[0,0,woodland.treeCount]);
console.log(`OK: ${woodland.treeCount} real mature trees; LOD caps, distant switch, foliage masks and shared materials valid`);
const bytes=await readFile(new URL('./assets/terrain/kaiser-height.f32',import.meta.url));
const elevation=new Float32Array(bytes.buffer.slice(bytes.byteOffset,bytes.byteOffset+bytes.byteLength));
const texture=new THREE.Texture(),set={color:texture,normal:texture,roughness:texture};
const nature={elevation,aerial:texture,rock:set,gravel:set};
const mountain=createMountains(scene,nature);mountain.geometry.computeBoundingBox();
assert.equal(mountain.geometry.index.count/3,130050);
assert(mountain.geometry.boundingBox.max.y>390&&mountain.geometry.boundingBox.max.y<410);
const stream=createStream(scene,nature,{riverX,riverWidth});
assert(stream.water.material.fragmentShader.includes('float rf0 = 0.0204;'));
assert(!stream.water.material.fragmentShader.includes('vec3 outgoingLight = albedo;'));
assert(stream.water.material.fragmentShader.includes('vec2 reflectedUv='),'Reflection filtering patch failed');
assert(stream.water.material.vertexShader.includes('streamCoordinate=uv;'),'Stream UV varying patch failed');
const flowUv=stream.water.geometry.attributes.uv;
assert.equal(flowUv.getY(0),0);assert(flowUv.getY(flowUv.count-1)>1000);
for(let i=13;i<flowUv.count;i+=13)assert(flowUv.getY(i)>flowUv.getY(i-13),'Flow distance must increase downstream');
assert(!stream.water.material.fragmentShader.includes('float a=cross*'),'Old striped sine-wave field still active');
assert(!stream.water.material.fragmentShader.includes('float lace='),'Old periodic foam field still active');
stream.update(8);assert.equal(stream.water.material.uniforms.time.value,8);
for(const mesh of [mountain,stream.water])for(const attr of Object.values(mesh.geometry.attributes))assert(attr.array.every(Number.isFinite));
console.log(`OK: ${Object.keys(models).length} real asset sets loaded, variants finite, building bounds valid, DEM and stream geometry complete (CPU only)`);
