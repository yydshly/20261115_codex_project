import * as THREE from 'three';
import { treeWindTime } from './model-assets.js';

/** Real mature tree geometry at three distances, batched by LOD and material. */
export function createModelWoodland(scene,library,{heightAt,riverX,random}){
  const group=new THREE.Group();group.name='Mature model trees and valley forest';scene.add(group);
  const trees=[];
  function tree(x,z,height){
    if(Math.abs(x-riverX(z))<8.5)return;
    trees.push({x,y:heightAt(x,z),z,height,angle:random()*Math.PI*2,width:.88+random()*.22});
  }
  tree(-8.7,-1.3,8.0);tree(9.5,-14.8,9.0);tree(-9.4,-22,8.5);
  for(let i=0;i<160;i++)tree(-170+random()*340,-220+random()*140,9+random()*6);
  for(let i=0;i<39;i++){
    const x=-171+i*9;tree(x,-67+Math.sin(x*.037)*7+(random()-.5)*5,9+random()*4.5);
  }
  for(let i=0;i<30;i++)tree((i%2?1:-1)*(54+random()*70),-45+random()*110,9+random()*6);
  const variants=['matureNear','matureFar','matureDistant'].map(id=>library[id][0]);
  const pools=variants.map((variant,level)=>variant.parts.map(part=>{
    const mesh=new THREE.InstancedMesh(part.geometry,part.material,trees.length);mesh.count=0;
    mesh.name=`Mature tree LOD ${level} · ${part.material.name}`;
    mesh.castShadow=level<2;mesh.receiveShadow=true;mesh.frustumCulled=false;
    group.add(mesh);return mesh;
  }));
  const dummy=new THREE.Object3D(),lastPosition=new THREE.Vector3(Infinity,0,0);
  let lastUpdate=-100,high=true;
  function update(time,camera){
    treeWindTime.value=time;
    const position=camera?.position||new THREE.Vector3(15,14,38);
    if(time-lastUpdate<.35||position.distanceToSquared(lastPosition)<1.4**2)return;
    lastUpdate=time;lastPosition.copy(position);
    const ordered=trees.map(t=>({tree:t,distance:Math.hypot(t.x-position.x,t.y-position.y,t.z-position.z)})).sort((a,b)=>a.distance-b.distance);
    const counts=[0,0,0];
    for(const {tree:t,distance} of ordered){
      const level=distance<54&&counts[0]<(high?6:2)?0:distance<112&&counts[1]<(high?22:10)?1:2;
      const scale=t.height/variants[level].size.y;
      dummy.position.set(t.x,t.y,t.z);dummy.rotation.set(0,t.angle,0);dummy.scale.set(scale*t.width,scale,scale*t.width);dummy.updateMatrix();
      for(const mesh of pools[level])mesh.setMatrixAt(counts[level],dummy.matrix);
      counts[level]++;
    }
    for(let level=0;level<3;level++)for(const mesh of pools[level]){mesh.count=counts[level];mesh.instanceMatrix.needsUpdate=true;}
  }
  update(0);
  return {group,treeCount:trees.length,colliders:trees.map(t=>({minX:t.x-.36,maxX:t.x+.36,minZ:t.z-.36,maxZ:t.z+.36})),
    update,setQuality(value){high=value;lastUpdate=-100;lastPosition.set(Infinity,0,0);}};
}
