import * as THREE from 'three';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
import { pathFrameAt,pathSampleAt } from './path-layout.js';
import { surfaceFieldAt } from './surface-field.js';

/** Licensed, textured GLBs; the person's original skeleton/animation stay intact. */
export async function loadValleyLife(renderer){
  const loader=new GLTFLoader(),result={};
  await Promise.all(['gardener','cow'].map(async id=>{
    const gltf=await loader.loadAsync(new URL(`./assets/models/life/${id}.glb`,import.meta.url).href);
    gltf.scene.traverse(o=>{
      if(!o.isMesh)return;o.castShadow=true;o.receiveShadow=true;
      for(const m of Array.isArray(o.material)?o.material:[o.material]){
        m.metalness=0;m.roughness=Math.max(.72,m.roughness);m.envMapIntensity=.55;
        for(const key of ['map','normalMap','roughnessMap'])if(m[key])m[key].anisotropy=Math.min(8,renderer.capabilities.getMaxAnisotropy());
      }
    });
    gltf.scene.updateMatrixWorld(true);const bounds=new THREE.Box3().setFromObject(gltf.scene,true);
    result[id]={...gltf,bounds,size:bounds.getSize(new THREE.Vector3())};
  }));
  return result;
}

export function createValleyLife(scene,assets,{heightAt,walkHeight,animate=true}){
  const group=new THREE.Group();group.name='A garden resident and two pasture cattle';scene.add(group);
  const gardener=new THREE.Group();gardener.name='Garden resident · animated walk';group.add(gardener);
  const human=assets.gardener.scene;gardener.add(human);
  human.position.x-=assets.gardener.bounds.getCenter(new THREE.Vector3()).x;
  human.position.z-=assets.gardener.bounds.getCenter(new THREE.Vector3()).z;human.position.y-=assets.gardener.bounds.min.y;
  const mixer=new THREE.AnimationMixer(human),walkClip=assets.gardener.animations.find(c=>c.name.toLowerCase()==='walk');
  if(!walkClip)throw new Error('人物模型缺少行走动画');
  const action=mixer.clipAction(walkClip);action.play();mixer.setTime(0);
  const cattle=[],contacts=[],walkerCollider={minX:0,maxX:0,minZ:0,maxZ:0},colliders=[walkerCollider];
  for(const [index,cx,cz,heading,h] of [[0,7,11,1.2,1.40],[1,18,-6,-.8,1.29]]){
    let best=null;
    for(let dx=-3;dx<=3;dx++)for(let dz=-3;dz<=3;dz++){
      const x=cx+dx,z=cz+dz;
      if((Math.abs(x)<13.5&&z>-24&&z<8.5)||pathSampleAt(x,z).distance<2)continue;
      const y=heightAt(x,z),spread=Math.max(...[-1,1].flatMap(a=>[-1,1].map(b=>Math.abs(heightAt(x+a*.45,z+b*1.2)-y))));
      const score=spread+surfaceFieldAt(x,z).bare*4+Math.hypot(dx,dz)*.012;
      if(!best||score<best.score)best={x,z,y,score};
    }
    const cow=new THREE.Group();cow.name=`Pasture cow ${index+1} · static textured model`;group.add(cow);
    const mesh=assets.cow.scene.clone(true),scale=h/assets.cow.size.y;mesh.scale.setScalar(scale);mesh.position.y=-assets.cow.bounds.min.y*scale;cow.add(mesh);
    const sx=(heightAt(best.x+.8,best.z)-heightAt(best.x-.8,best.z))/1.6,sz=(heightAt(best.x,best.z+.8)-heightAt(best.x,best.z-.8))/1.6;
    cow.quaternion.setFromUnitVectors(new THREE.Vector3(0,1,0),new THREE.Vector3(-sx,1,-sz).normalize());cow.rotateY(heading);
    cow.position.set(best.x,best.y+.005,best.z);cattle.push({group:cow,...best,height:h});
    contacts.push({x:best.x,z:best.z,radius:.65,occlusion:.35});
    const halfX=(Math.abs(Math.cos(heading))*.40+Math.abs(Math.sin(heading))*1.20)*scale;
    const halfZ=(Math.abs(Math.sin(heading))*.40+Math.abs(Math.cos(heading))*1.20)*scale;
    colliders.push({minX:best.x-halfX,maxX:best.x+halfX,minZ:best.z-halfZ,maxZ:best.z+halfZ});
  }
  const animalBounds=colliders.slice(1).map(c=>({...c}));
  let clock=6,lastShadow=-Infinity,high=true;
  function update(dt,time,camera){
    const distance=Math.hypot(gardener.position.x-camera.position.x,gardener.position.z-camera.position.z);
    if(animate&&group.visible&&distance>1.8)clock+=dt;
    // Keep this short route clear of the normal garden arrival point.
    const travel=8,turn=2,period=2*(travel+turn),phase=clock%period;
    let s,heading,moving;
    if(phase<travel){s=2.2+phase*.45;heading=0;moving=true;}
    else if(phase<travel+turn){s=5.8;heading=Math.PI*THREE.MathUtils.smoothstep(phase,travel,travel+turn);moving=false;}
    else if(phase<2*travel+turn){s=5.8-(phase-travel-turn)*.45;heading=Math.PI;moving=true;}
    else{s=2.2;heading=Math.PI+Math.PI*THREE.MathUtils.smoothstep(phase,2*travel+turn,period);moving=false;}
    const f=pathFrameAt(s);gardener.position.set(f.x,walkHeight(f.x,f.z)+.012,f.z);
    gardener.rotation.y=Math.atan2(-f.nz,f.nx)+heading;
    if(group.visible)Object.assign(walkerCollider,{minX:f.x-.24,maxX:f.x+.24,minZ:f.z-.24,maxZ:f.z+.24});
    // Pair the short garden route with a slower source gait.
    action.timeScale=moving&&animate&&distance>1.8?.44:0;
    if(!moving||distance<=1.8)mixer.setTime(0);else mixer.update(dt);
    gardener.visible=distance<(high?125:85);
    for(const c of cattle)c.group.visible=c.group.position.distanceTo(camera.position)<(high?320:210);
    if(group.visible&&gardener.visible&&animate&&time-lastShadow>.14){lastShadow=time;return true;}
    return false;
  }
  return {group,gardener,cattle,contacts,colliders,mixer,walkClip,update,setQuality(value){high=value;},setVisible(value){
    group.visible=value;
    for(let i=0;i<colliders.length;i++)Object.assign(colliders[i],value?(i?animalBounds[i-1]:{minX:gardener.position.x-.24,maxX:gardener.position.x+.24,minZ:gardener.position.z-.24,maxZ:gardener.position.z+.24}):{minX:Infinity,maxX:-Infinity,minZ:Infinity,maxZ:-Infinity});
  }};
}
