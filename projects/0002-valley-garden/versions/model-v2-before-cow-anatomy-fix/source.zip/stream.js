import * as THREE from 'three';
import { Water } from 'three/addons/objects/Water.js';
import { tiledMaterialMaps } from './nature.js';
import { budgetReflections } from './reflection-budget.js';
import { streamBedProfileAt,createStreamProfileTexture } from './stream-profile.js';

/** Realtime reflected water over a separate, shadow-receiving gravel stream bed. */
export function createStream(scene,nature,{riverX,riverWidth}){
  const positions=[],uv=[],indices=[],bottom=[],sections=650,across=12;
  let arcLength=0,previousZ=-650,previousX=riverX(previousZ);
  for(let i=0;i<=sections;i++){
    const z=-650+i*1000/sections,w=riverWidth(z),cx=riverX(z);
    if(i)arcLength+=Math.hypot(z-previousZ,cx-previousX);
    previousZ=z;previousX=cx;
    for(let j=0;j<=across;j++){
      const t=j/across,x=cx+(t*2-1)*w,depth=streamBedProfileAt(z,t).depth;
      // Metres across the channel, and cumulative centre-line arc length downstream.
      positions.push(x,-z,0);uv.push((t*2-1)*w,arcLength);
      bottom.push(x,-.05-depth,z);
      if(i<sections&&j<across){const a=i*(across+1)+j;indices.push(a,a+across+1,a+1,a+1,a+across+1,a+across+2);}
    }
  }
  const geometry=new THREE.BufferGeometry();geometry.setAttribute('position',new THREE.Float32BufferAttribute(positions,3));geometry.setAttribute('uv',new THREE.Float32BufferAttribute(uv,2));geometry.setIndex(indices);geometry.computeVertexNormals();
  const bedGeometry=new THREE.BufferGeometry();bedGeometry.setAttribute('position',new THREE.Float32BufferAttribute(bottom,3));
  const bedUv=[];for(let i=0;i<bottom.length;i+=3)bedUv.push(bottom[i]*.65,bottom[i+2]*.65);
  bedGeometry.setAttribute('uv',new THREE.Float32BufferAttribute(bedUv,2));bedGeometry.setIndex(indices);bedGeometry.computeVertexNormals();
  const bed=new THREE.Mesh(bedGeometry,new THREE.MeshStandardMaterial({...tiledMaterialMaps(nature.gravel,1),color:'#8b978b',roughness:1,normalScale:new THREE.Vector2(.65,.65),side:THREE.DoubleSide}));bed.receiveShadow=true;bed.name='Contoured gravel river bed';scene.add(bed);
  const data=new Uint8Array([128,128,255,255]);const normal=new THREE.DataTexture(data,1,1);normal.needsUpdate=true;
  const water=new Water(geometry,{textureWidth:512,textureHeight:512,waterNormals:normal,sunDirection:new THREE.Vector3(-48,68,40).normalize(),sunColor:0xfff2dc,waterColor:0x3d7270,distortionScale:.42,fog:true});
  water.name='Flowing stream · reflection, shallow refraction, absorption';water.rotation.x=-Math.PI/2;water.position.y=-.05;
  const material=water.material;material.uniforms.streamBedMap={value:nature.gravel.color};
  material.uniforms.streamProfileMap={value:createStreamProfileTexture()};
  material.uniforms.streamRocks={value:Array.from({length:9},()=>new THREE.Vector4())};material.uniforms.streamRockCount={value:0};
  material.vertexShader='varying vec2 streamCoordinate;\n'+material.vertexShader;
  material.vertexShader=material.vertexShader.replace('mirrorCoord = modelMatrix * vec4( position, 1.0 );','streamCoordinate=uv;\nmirrorCoord = modelMatrix * vec4( position, 1.0 );');
  material.fragmentShader='uniform sampler2D streamBedMap,streamProfileMap; uniform vec4 streamRocks[9]; uniform int streamRockCount; varying vec2 streamCoordinate;\n'+material.fragmentShader;
  const start=material.fragmentShader.indexOf('vec4 getNoise('),end=material.fragmentShader.indexOf('void sunLight(',start);
  material.fragmentShader=material.fragmentShader.slice(0,start)+`
    float channelCenter(float z){return -28.+40.*exp(-pow((z-30.)/22.,2.))+2.*sin(z*.028);}
    float channelWidth(float z){return 3.5+.7*sin(z*.025+1.)+.22*sin(z*.17)+.08*sin(z*.51+2.);}
    vec3 bedProfile(vec2 world){return texture2D(streamProfileMap,vec2(clamp((world.x-channelCenter(world.y))/(2.*channelWidth(world.y))+.5,0.,1.),clamp((world.y+650.)/1000.,0.,1.))).rgb;}
    vec2 flowDirection(float z){float slope=-80.*(z-30.)/(22.*22.)*exp(-pow((z-30.)/22.,2.))+.056*cos(z*.028);return normalize(vec2(slope,1.));}
    float flowNoise(vec2 p);
    vec3 obstacleWake(vec2 world){
      vec2 tangent=flowDirection(world.y),across=vec2(tangent.y,-tangent.x),gradient=vec2(0.);float foam=0.;
      for(int i=0;i<9;i++){
        if(i>=streamRockCount)break;
        vec2 delta=world-streamRocks[i].xy;float radius=streamRocks[i].z;
        float along=dot(delta,tangent),side=dot(delta,across);
        float spread=radius*.8+max(0.,along)*.16;
        float envelope=smoothstep(-radius,.2,along)*(1.-smoothstep(radius,radius*8.,along))*exp(-side*side/max(.025,spread*spread));
        float travel=along-time*.48;
        float wakeRidge=cos((abs(side)-max(0.,along)*.18)*24.-time*2.4);
        gradient+=(tangent*cos(travel*14.)+across*wakeRidge*.45)*envelope*.030;
        float nose=(along+radius*.72)/.10,flank=abs(side)/max(.08,radius*.9);
        float bow=exp(-nose*nose)*exp(-flank*flank*flank*flank);
        float trailSide=(abs(side)-radius*.52-max(0.,along)*.11)/max(.07,radius*.24);
        float strands=exp(-trailSide*trailSide);
        float bubbles=smoothstep(.52,.83,flowNoise(vec2(side*24.,travel*15.)));
        foam+=bow*.35+envelope*strands*bubbles*.75;
      }
      return vec3(gradient,clamp(foam,0.,1.));
    }
    // Small multipliers retain float precision along the kilometre-scale arc UV.
    float flowHash(vec2 p){vec3 h=fract(vec3(p.xyx)*vec3(.1031,.1030,.0973));h+=dot(h,h.yzx+33.33);return fract((h.x+h.y)*h.z);}
    float flowNoise(vec2 p){
      vec2 i=floor(p),f=fract(p);f=f*f*(3.-2.*f);
      return mix(mix(flowHash(i),flowHash(i+vec2(1.,0.)),f.x),mix(flowHash(i+vec2(0.,1.)),flowHash(i+1.),f.x),f.y);
    }
    float flowHeight(vec2 p){
      p+=vec2(flowNoise(p*.27+8.1),flowNoise(p*.19-3.7))*.63;
      mat2 rotation=mat2(.83,-.56,.56,.83);
      return (flowNoise(p*vec2(2.8,1.45))-.5)*.014
        +(flowNoise(rotation*p*5.1)-.5)*.006
        +(flowNoise(rotation*p*11.7+17.)-.5)*.002;
    }
    vec4 getNoise(vec2 ignored){
      float width=channelWidth(worldPosition.z);
      float centre=1.-clamp(abs(streamCoordinate.x)/width,0.,1.);
      // Bounded shear avoids stretching cross-channel wavelengths forever.
      float shear=sin(time*.23)*centre*.34;
      vec2 p=streamCoordinate-vec2(0.,time*.48+shear);
      float epsilon=.035+min(length(eye-worldPosition.xyz)*.0009,.12);
      float dx=(flowHeight(p+vec2(epsilon,0.))-flowHeight(p-vec2(epsilon,0.)))/(2.*epsilon);
      float dy=(flowHeight(p+vec2(0.,epsilon))-flowHeight(p-vec2(0.,epsilon)))/(2.*epsilon);
      vec2 tangent=flowDirection(worldPosition.z),across=vec2(tangent.y,-tangent.x);
      float riffle=bedProfile(worldPosition.xz).g;
      vec2 gradient=(across*dx+tangent*dy)*mix(.65,1.65,riffle)+obstacleWake(worldPosition.xz).xy;
      return vec4(-gradient.x,-gradient.y,1.,1.);
    }
  `+material.fragmentShader.slice(end);
  material.fragmentShader=material.fragmentShader.replace('float rf0 = 0.3;','float rf0 = 0.0204;')
    .replace('100.0, 2.0, 0.5','180.0, 1.05, 0.5')
    .replace('vec3 outgoingLight = albedo;',`
      float width=channelWidth(worldPosition.z);
      float edge=clamp((width-abs(worldPosition.x-channelCenter(worldPosition.z)))/width,0.,1.);
      vec3 profile=bedProfile(worldPosition.xz);
      float depth=profile.r*1.6;
      vec2 bedUv=worldPosition.xz*.65+surfaceNormal.xz*.18*depth;
      vec3 gravel=texture2D(streamBedMap,bedUv).rgb;
      vec2 moving=streamCoordinate-vec2(0.,time*.57);
      float caustic=pow(1.-abs(flowNoise(moving*4.4+surfaceNormal.xz*.3)*2.-1.),16.);
      vec3 transmittance=exp(-vec3(.48,.24,.17)*depth*1.7);
      vec3 bedLight=gravel*vec3(.69,.75,.66)*(1.+caustic*.075)*(.36+.64*getShadowMask());
      vec3 refraction=bedLight*transmittance+vec3(.026,.085,.072)*(1.-transmittance);
      vec3 outgoingLight=mix(refraction,reflectionSample,reflectance)+specularLight*.32;
      float bankMetres=width-abs(worldPosition.x-channelCenter(worldPosition.z));
      float shore=1.-smoothstep(.015,.20,bankMetres);
      float patches=smoothstep(.64,.84,flowNoise(moving*vec2(6.2,2.1)));
      outgoingLight=mix(outgoingLight,vec3(.53,.61,.56),shore*patches*.045);
      float wakeFoam=obstacleWake(worldPosition.xz).z;
      float riffleFoam=smoothstep(.68,.87,flowNoise(moving*vec2(8.,2.1)+vec2(flowNoise(moving*1.3)*2.,0.)))*profile.g*.12;
      vec3 foamLight=vec3(.69,.75,.69)*(.35+.65*getShadowMask());
      outgoingLight=mix(outgoingLight,foamLight,clamp(wakeFoam*.34+riffleFoam,0.,.34));
    `);
  material.fragmentShader=material.fragmentShader.replace(/vec3 reflectionSample = vec3\( texture2D\( mirrorSampler, mirrorCoord.xy \/ mirrorCoord.w \+ distortion \) \);/,`
    vec2 reflectedUv=mirrorCoord.xy/mirrorCoord.w+distortion;
    vec3 reflectionSample=texture2D(mirrorSampler,reflectedUv).rgb*.5;
    reflectionSample+=(texture2D(mirrorSampler,reflectedUv+vec2(.0007,0.)).rgb
      +texture2D(mirrorSampler,reflectedUv-vec2(.0007,0.)).rgb
      +texture2D(mirrorSampler,reflectedUv+vec2(0.,.0007)).rgb
      +texture2D(mirrorSampler,reflectedUv-vec2(0.,.0007)).rgb)*.125;
  `);
  scene.add(water);
  const driftGeometry=new THREE.BufferGeometry();
  driftGeometry.setAttribute('position',new THREE.Float32BufferAttribute([0,.004,-.052,-.025,0,-.008,0,.003,.058,.025,0,-.008],3));
  driftGeometry.setIndex([0,1,2,0,2,3]);driftGeometry.computeVertexNormals();
  const drift=new THREE.InstancedMesh(driftGeometry,new THREE.MeshStandardMaterial({color:'#81764f',roughness:.94,side:THREE.DoubleSide}),16);
  drift.name='Sixteen fallen leaves drifting downstream';drift.castShadow=false;drift.receiveShadow=true;drift.frustumCulled=false;scene.add(drift);
  const leaf=new THREE.Object3D(),leafColour=new THREE.Color();
  for(let i=0;i<16;i++){leafColour.setHSL(.13+(i%4)*.011,.17+(i%3)*.07,.22+(i%5)*.025);drift.setColorAt(i,leafColour);}
  function updateDrift(time){
    for(let i=0;i<16;i++){
      const z=-55+((i*7.5+time*.42)%120),u=Math.sin(i*7.73)*.64+Math.sin(time*.11+i)*.035;
      leaf.position.set(riverX(z)+u*riverWidth(z),-.042+Math.sin(time*1.4+i)*.0012,z);
      leaf.rotation.set(Math.sin(time*.7+i)*.022,i*2.4+Math.sin(time*.17+i)*.18,Math.cos(time*.63+i)*.025);leaf.scale.setScalar(.72+(i%5)*.14);leaf.updateMatrix();drift.setMatrixAt(i,leaf.matrix);
    }
    drift.instanceMatrix.needsUpdate=true;
  }
  updateDrift(0);
  const reflectionBudget=budgetReflections(water,scene);
  return {water,bed,drift,profileAt:streamBedProfileAt,setObstacles(rocks){material.uniforms.streamRockCount.value=Math.min(9,rocks.length);rocks.slice(0,9).forEach((r,i)=>material.uniforms.streamRocks.value[i].set(r.x,r.z,r.radius,0));},update(time){material.uniforms.time.value=time;updateDrift(time);},setQuality(high){reflectionBudget.setQuality(high);material.uniforms.distortionScale.value=high?.42:.25;}};
}
