import * as THREE from 'three';

const smooth=THREE.MathUtils.smoothstep;
const templates=new WeakMap();

function prepare(source){
  if(templates.has(source))return templates.get(source);
  source.updateMatrixWorld(true);const meshes=[];source.traverse(o=>{if(o.isMesh)meshes.push(o);});
  if(meshes.length!==1)throw new Error('当前奶牛动作需要单一静态网格');
  const input=meshes[0],geometry=input.geometry.clone().applyMatrix4(input.matrixWorld),p=geometry.attributes.position;
  const indices=new Uint16Array(p.count*4),weights=new Float32Array(p.count*4);let muzzle=0,nearest=Infinity;
  for(let i=0;i<p.count;i++){
    const x=p.getX(i),y=p.getY(i),z=p.getZ(i);
    const neck=smooth(z,.24,.69)*smooth(y,.55,.90),head=neck*smooth(z,.62,.87);
    const jaw=head*smooth(z,.85,1.06)*(1-smooth(y,1.015,1.12))*.85;
    const tail=(1-smooth(z,-1.08,-.92))*(1-smooth(Math.abs(x+.075),.07,.14))*(1-smooth(y,.94,1.10));
    const scores=tail>.05?[[4,tail],[0,1-tail]]:[[0,1-neck],[1,neck-head],[2,head-jaw],[3,jaw]];
    scores.forEach(([bone,weight],j)=>{indices[i*4+j]=bone;weights[i*4+j]=weight;});
    // Lowest muzzle support point after the combined 1.38 rad grazing pitch.
    const d=y*.19-z*.982;if(z>.90&&y<1.20&&d<nearest){nearest=d;muzzle=i;}
  }
  geometry.setAttribute('skinIndex',new THREE.Uint16BufferAttribute(indices,4));geometry.setAttribute('skinWeight',new THREE.Float32BufferAttribute(weights,4));
  // Only the fixed torso/legs enter the cached sun map. The moving neck has no stale self-shadow.
  const caster=geometry.clone(),triangles=[],index=geometry.index;
  for(let i=0;i<index.count;i+=3){const a=index.getX(i),b=index.getX(i+1),c=index.getX(i+2);if([a,b,c].every(v=>indices[v*4]===0&&weights[v*4]>.999))triangles.push(a,b,c);}
  caster.setIndex(triangles);
  const template={geometry,caster,material:input.material,muzzle,restMuzzle:new THREE.Vector3().fromBufferAttribute(p,muzzle)};
  templates.set(source,template);return template;
}

/** Runtime armature over the retained static GLB; feet and torso stay planted. */
export function createGrazingCow(source,{phaseOffset=6,animate=true,surfaceHeight}){
  const template=prepare(source),root=new THREE.Group(),body=new THREE.Bone(),neck=new THREE.Bone(),head=new THREE.Bone(),jaw=new THREE.Bone(),tail=new THREE.Bone();
  body.name='Cow fixed body';neck.name='Cow neck';head.name='Cow head';jaw.name='Cow jaw';tail.name='Cow tail';
  neck.position.set(0,1.04,.33);head.position.set(.14,.06,.44);jaw.position.set(0,-.10,.25);tail.position.set(-.075,.96,-.94);
  body.add(neck,tail);neck.add(head);head.add(jaw);
  const mesh=new THREE.SkinnedMesh(template.geometry,template.material);mesh.name='Cow · neck, head, chewing jaw and tail';mesh.add(body);mesh.bind(new THREE.Skeleton([body,neck,head,jaw,tail]));mesh.castShadow=false;mesh.receiveShadow=true;mesh.frustumCulled=false;root.add(mesh);
  const shadow=new THREE.Mesh(template.caster,new THREE.MeshBasicMaterial({colorWrite:false,depthWrite:false}));shadow.name='Cow fixed torso shadow';shadow.castShadow=true;shadow.userData.shadowOnly=true;root.add(shadow);
  const point=new THREE.Vector3(),rest=new THREE.Vector3();
  const state={phase:'grazing',graze:1,muzzleClearance:0,jaw:0,tail:0};
  function update(time){
    const phase=animate?(time+phaseOffset)%38:6;
    const graze=phase<20?1:phase<23?1-smooth(phase,20,23):phase<28?0:phase<31?smooth(phase,28,31):1;
    state.phase=phase<20||phase>=31?'grazing':phase<23?'raising':phase<28?'looking':'lowering';state.graze=graze;
    neck.position.y=1.04;neck.rotation.set(graze*1.0,animate?Math.sin(time*.41+phaseOffset)*.025:0,0);
    head.rotation.set(graze*.38,animate?Math.sin(time*.37+phaseOffset)*(.025+.07*(1-graze)):0,0);
    state.jaw=animate?(Math.sin(time*5.8+phaseOffset)*.025+.015)*(graze*.75+.25):0;
    jaw.rotation.set(state.jaw,0,animate?Math.sin(time*6.3+phaseOffset)*.012:0);
    state.tail=animate?Math.sin(time*1.13+phaseOffset)*(.12+.16*Math.max(0,Math.sin(time*.17+phaseOffset))):0;tail.rotation.z=state.tail;
    root.updateWorldMatrix(true,false);root.updateMatrixWorld(true);
    mesh.getVertexPosition(template.muzzle,point).applyMatrix4(mesh.matrixWorld);rest.copy(template.restMuzzle).applyMatrix4(mesh.matrixWorld);
    const floor=surfaceHeight(point.x,point.z),target=THREE.MathUtils.lerp(rest.y,floor+.045,graze);
    neck.position.y+=(target-point.y)/mesh.matrixWorld.elements[5];
    root.updateMatrixWorld(true);mesh.getVertexPosition(template.muzzle,point).applyMatrix4(mesh.matrixWorld);
    state.muzzleClearance=point.y-surfaceHeight(point.x,point.z);
  }
  return {root,mesh,shadow,state,update,muzzleIndex:template.muzzle};
}
