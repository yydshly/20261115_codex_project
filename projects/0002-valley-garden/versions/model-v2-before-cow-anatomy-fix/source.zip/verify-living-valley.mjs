import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import * as THREE from 'three';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
import { createGrazingCow } from './cattle-behavior.js';
import { createStream } from './stream.js';
import { riverX,riverWidth } from './terrain.js';
import { grazingInfluenceAt,meadowGrowthAt } from './meadow-field.js';

const loader=new GLTFLoader();loader.register(()=>({name:'CPUAnimalInspection',loadTexture:async()=>new THREE.Texture()}));
const bytes=await readFile(new URL('./assets/models/life/cow.glb',import.meta.url));
const asset=await loader.parseAsync(bytes.buffer.slice(bytes.byteOffset,bytes.byteOffset+bytes.byteLength),'');
let original;asset.scene.traverse(o=>{if(o.isMesh)original=o;});
const before=original.geometry.attributes.position.array.slice(),floor=.18;
const cow=createGrazingCow(asset.scene,{surfaceHeight:()=>floor}),other=createGrazingCow(asset.scene,{phaseOffset:23.5,surfaceHeight:()=>floor});
cow.root.position.set(7,floor,11);cow.root.rotation.y=1.2;cow.root.scale.setScalar(.99);
assert.equal(cow.mesh.geometry,other.mesh.geometry,'Cattle duplicate their prepared geometry');
assert.notEqual(cow.mesh.skeleton,other.mesh.skeleton,'Cattle share one animated skeleton');
const position=cow.mesh.geometry.attributes.position,point=new THREE.Vector3(),rest=new THREE.Vector3(),hooves=[];
for(let i=0;i<position.count;i+=7)if(position.getY(i)<.045)hooves.push(i);
const phases=new Set();let minJaw=Infinity,maxJaw=-Infinity,minTail=Infinity,maxTail=-Infinity,maxHoofError=0,minHead=Infinity;
for(let frame=0;frame<1140;frame++){
  const t=frame/30;cow.update(t);other.update(t);phases.add(cow.state.phase);
  minJaw=Math.min(minJaw,cow.state.jaw);maxJaw=Math.max(maxJaw,cow.state.jaw);minTail=Math.min(minTail,cow.state.tail);maxTail=Math.max(maxTail,cow.state.tail);
  if(cow.state.graze>.999)assert(Math.abs(cow.state.muzzleClearance-.045)<.001,'Grazing muzzle misses the cropped grass');
  for(const index of hooves){cow.mesh.getVertexPosition(index,point).applyMatrix4(cow.mesh.matrixWorld);rest.fromBufferAttribute(position,index).applyMatrix4(cow.mesh.matrixWorld);maxHoofError=Math.max(maxHoofError,point.distanceTo(rest));}
  if(frame%95===0)for(let i=0;i<position.count;i++){if(position.getZ(i)<.87)continue;cow.mesh.getVertexPosition(i,point).applyMatrix4(cow.mesh.matrixWorld);minHead=Math.min(minHead,point.y-floor);}
}
assert.deepEqual([...phases].sort(),['grazing','looking','lowering','raising']);assert(maxHoofError<1e-6,'Grazing rocks the planted hooves');assert(minHead>.02,'Grazing pushes the head into the ground');
assert(maxJaw-minJaw>.035&&maxTail-minTail>.2,'Chewing or tail motion is missing');
cow.update(0);other.update(0);assert(cow.state.graze>.99&&other.state.graze<.01,'Both cows perform an identical cycle');
assert.deepEqual(original.geometry.attributes.position.array,before,'Runtime rig modified the retained source mesh');assert(!original.geometry.attributes.skinIndex,'Runtime skin weights leaked into the source');
const texture=new THREE.Texture(),maps={color:texture,normal:texture,roughness:texture};
const stream=createStream(new THREE.Scene(),{gravel:maps},{riverX,riverWidth}),first=Array.from(stream.drift.instanceMatrix.array);stream.update(10);
for(let i=0;i<16;i++){const m=stream.drift.instanceMatrix.array,x=m[i*16+12],z=m[i*16+14];assert(Math.abs(x-riverX(z))<riverWidth(z)*.75,'A drifting leaf left the water');assert(Math.abs(z-first[i*16+14]-4.2)<.00002,'Leaves do not advect downstream');assert(m[i*16+13]>-.05,'A leaf intersects the water plane');}
const sites=[{x:7,z:11,grazingRadius:2.8}];assert(grazingInfluenceAt(7,11,sites)>.99&&grazingInfluenceAt(15,11,sites)===0);
const growth=Array.from({length:100},(_,i)=>meadowGrowthAt(i*.53,Math.sin(i)*5));assert(Math.max(...growth)-Math.min(...growth)>.5,'Pasture growth has no coherent variation');
console.log('OK: grazing/raising/looking/lowering, chewing and tail motion; hoof drift '+maxHoofError.toFixed(8)+' m, minimum head clearance '+minHead.toFixed(3)+' m; drifting leaves stay in the channel');
