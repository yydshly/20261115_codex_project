// CPU validation of actual glTF data and scene geometry; it does not claim GPU visual QA.
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import * as THREE from 'three';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
import { loadModelLibrary, createModelCottage } from './model-assets.js';
import { createMountains } from './mountains.js';
import { createStream } from './stream.js';
import { riverX, riverWidth } from './landscape.js';

const originalFetch=globalThis.fetch;
globalThis.fetch=async (request,options)=>{
  const url=typeof request==='string'?request:request instanceof URL?request.href:request.url;
  if(url.startsWith('file:')){
    const bytes=await readFile(new URL(url));return new Response(bytes,{headers:{'Content-Length':String(bytes.length)}});
  }
  return originalFetch(request,options);
};
globalThis.ProgressEvent=class extends Event{constructor(type,details){super(type);Object.assign(this,details);}};
THREE.TextureLoader.prototype.loadAsync=async()=>new THREE.Texture();
GLTFLoader.prototype.loadAsync=async function(url){
  this.register(()=>({name:'CPUAssetInspection',loadTexture:async()=>new THREE.Texture()}));
  const bytes=await readFile(new URL(url));
  return this.parseAsync(bytes.buffer.slice(bytes.byteOffset,bytes.byteOffset+bytes.byteLength),new URL('.',url).href);
};
const renderer={capabilities:{getMaxAnisotropy:()=>8}};
const models=await loadModelLibrary(renderer);
for(const [name,variants] of Object.entries(models))for(const variant of variants){
  assert(variant.size.y>0&&Number.isFinite(variant.size.y),`${name} has invalid height`);
  for(const part of variant.parts)for(const attr of Object.values(part.geometry.attributes)){
    assert(attr.array.every(Number.isFinite),`${name} contains non-finite vertex data`);
  }
}
const scene=new THREE.Scene();
for(const style of ['townhouse','house']){
  const house=createModelCottage(scene,models,style);
  const collider=house.colliders[0];
  assert(collider.minX<0&&collider.maxX>0&&collider.minZ<collider.maxZ);
  assert(collider.maxZ< -3,`${style} blocks the garden spawn`);
  console.log(`${style}: size ${models[style][0].size.toArray().map(x=>x.toFixed(3)).join(' × ')}, wall collider ${JSON.stringify(collider)}`);
}
const bytes=await readFile(new URL('./assets/terrain/kaiser-height.f32',import.meta.url));
const elevation=new Float32Array(bytes.buffer.slice(bytes.byteOffset,bytes.byteOffset+bytes.byteLength));
const texture=new THREE.Texture(),set={color:texture,normal:texture,roughness:texture};
const nature={elevation,aerial:texture,rock:set,gravel:set};
const mountain=createMountains(scene,nature);mountain.geometry.computeBoundingBox();
assert.equal(mountain.geometry.index.count/3,130050);
assert(mountain.geometry.boundingBox.max.y>390&&mountain.geometry.boundingBox.max.y<410);
const stream=createStream(scene,nature,{riverX,riverWidth});
assert(stream.water.material.fragmentShader.includes('float rf0 = 0.0204;'));
assert(!stream.water.material.fragmentShader.includes('vec3 outgoingLight = albedo;'));
stream.update(8);assert.equal(stream.water.material.uniforms.time.value,8);
for(const mesh of [mountain,stream.water])for(const attr of Object.values(mesh.geometry.attributes))assert(attr.array.every(Number.isFinite));
console.log(`OK: ${Object.keys(models).length} real asset sets loaded, variants finite, building bounds valid, DEM and stream geometry complete (CPU only)`);
