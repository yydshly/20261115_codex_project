import * as THREE from 'three';
import { createMountains } from './mountains.js';
import { createStream } from './stream.js';
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js';
import { tiledMaterialMaps } from './nature.js';

export function seededRandom(seed = 1206) {
  return () => ((seed = (1664525 * seed + 1013904223) >>> 0) / 4294967296);
}
const clamp = THREE.MathUtils.clamp;
const smooth = (a, b, x) => { const t = clamp((x-a)/(b-a), 0, 1); return t*t*(3-2*t); };
export function riverX(z) { return -28 + 40*Math.exp(-Math.pow((z-30)/22, 2)) + 2*Math.sin(z*0.028); }
export function riverWidth(z) { return 3.5 + 0.7*Math.sin(z*0.025+1); }
export function heightAt(x,z) {
  const far = smooth(28,100,Math.abs(x)) * (6+5*Math.sin(z*0.013+x*0.02));
  let y = 0.18 + far + smooth(25,100,Math.hypot(x,z+10))*0.7*(Math.sin(x*.07)*Math.cos(z*.035));
  if (Math.abs(x)<14 && z>-28 && z<12) y=0.18;
  const d = Math.abs(x-riverX(z));
  const channel = 1-smooth(riverWidth(z)-0.65,riverWidth(z)+1.5,d);
  y = y*(1-channel) - 1.05*channel;
  return y;
}

export function buildLandscape(scene, renderer, nature) {
  const random=seededRandom(570213), dummy=new THREE.Object3D();
  const colliders=[];
  const color=new THREE.Color();
  const terrainGeo=new THREE.PlaneGeometry(1100,1100,440,440);
  terrainGeo.rotateX(-Math.PI/2);
  const p=terrainGeo.attributes.position;
  const colors=[];
  for(let i=0;i<p.count;i++) {
    const x=p.getX(i),z=p.getZ(i)-150,y=heightAt(x,z);
    p.setXYZ(i,x,y,z);
    const variation=(Math.sin(x*.21+z*.13)+Math.sin(x*.63-z*.37))*.025+random()*.035;
    color.setRGB(.81+variation,.92+variation,.72+variation);
    if(Math.abs(x-riverX(z))<riverWidth(z)+1.6) color.set('#9c9d86').multiplyScalar(.85+random()*.3);
    colors.push(color.r,color.g,color.b);
  }
  terrainGeo.setAttribute('color',new THREE.Float32BufferAttribute(colors,3)); terrainGeo.computeVertexNormals();
  const terrain=new THREE.Mesh(terrainGeo,new THREE.MeshStandardMaterial({...tiledMaterialMaps(nature.grass,340),color:'#a2bd72',normalScale:new THREE.Vector2(.3,.3),vertexColors:true,roughness:1}));
  terrain.receiveShadow=true; scene.add(terrain);

  const mountains=createMountains(scene,nature);

  const sky=new THREE.Mesh(new THREE.SphereGeometry(1900,48,24),new THREE.MeshBasicMaterial({
    map:nature.sky,side:THREE.BackSide,depthWrite:false,fog:false
  }));
  sky.rotation.y=Math.PI*.65;sky.renderOrder=-10;scene.add(sky);

  // Low mist follows the mountain foot, rather than covering the nearby garden.
  const cloudMap=softTexture();
  const mist=[];
  for(let i=0;i<32;i++) {
    const sprite=new THREE.Sprite(new THREE.SpriteMaterial({map:cloudMap,color:'#e6eeeb',opacity:.06+random()*.05,depthWrite:false}));
    sprite.position.set((random()-.5)*1250,28+random()*35,-290-random()*340);
    sprite.scale.set(170+random()*220,18+random()*22,1);scene.add(sprite);mist.push(sprite);
  }

  const stream=createStream(scene,nature,{riverX,riverWidth}),water=stream.water;

  const bankV=[],bankC=[],bankI=[],bankUv=[];
  for(const side of [-1,1]){
    const offset=bankV.length/3;
    for(let i=0;i<=650;i++){
      const z=-650+i*1000/650,w=riverWidth(z),cx=riverX(z);
      for(const [d,h,c] of [[w-.08,-.09,'#858974'],[w+.95,.14,'#8c9570'],[w+2.5,null,'#6b8b45']]){
        const x=cx+side*d;bankV.push(x,h??heightAt(x,z)+.045,z);bankUv.push(x*.32,z*.32);const col=new THREE.Color(c).multiplyScalar(1.5);bankC.push(col.r,col.g,col.b);
      }
      if(i<650){const a=offset+i*3;bankI.push(a,a+3,a+1,a+1,a+3,a+4,a+1,a+4,a+2,a+2,a+4,a+5);}
    }
  }
  const bankGeo=new THREE.BufferGeometry();bankGeo.setAttribute('position',new THREE.Float32BufferAttribute(bankV,3));bankGeo.setAttribute('uv',new THREE.Float32BufferAttribute(bankUv,2));bankGeo.setAttribute('color',new THREE.Float32BufferAttribute(bankC,3));bankGeo.setIndex(bankI);bankGeo.computeVertexNormals();
  const banks=new THREE.Mesh(bankGeo,new THREE.MeshStandardMaterial({...tiledMaterialMaps(nature.gravel,1),normalScale:new THREE.Vector2(.55,.55),vertexColors:true,roughness:.9,side:THREE.DoubleSide}));banks.receiveShadow=true;scene.add(banks);

  // Near-bank rocks are imported scan assets in this edition.

  // The route is made of separate irregular flagstones, with living grass between.
  const stoneGeo=new THREE.CylinderGeometry(1,1,.075,7);const paths=[];
  for(let z=-2;z<12;z+=.68) for(let x=-.76;x<=.8;x+=.78) paths.push([x+(random()-.5)*.15,z+(random()-.5)*.1,.47+random()*.11]);
  for(let i=0;i<24;i++){const t=i/23;paths.push([-6*t,12+6*t,.55]);}
  const stones=new THREE.InstancedMesh(stoneGeo,new THREE.MeshStandardMaterial({...tiledMaterialMaps(nature.gravel,1),color:'#ccc9b8',normalScale:new THREE.Vector2(.2,.2),roughness:.96}),paths.length);
  paths.forEach(([x,z,s],i)=>{dummy.position.set(x,heightAt(x,z)+.055,z);dummy.rotation.set(0,random()*6,0);dummy.scale.set(s,1,s*.83);dummy.updateMatrix();stones.setMatrixAt(i,dummy.matrix);stones.setColorAt(i,color.setHSL(.12,.09,.53+random()*.18));});
  stones.receiveShadow=true;scene.add(stones);

  // White picket fence, open at the central gate and at the riverside.
  const fencePieces=[],posts=[],rails=[];
  const segments=[[-11,7,-1.6,7],[1.6,7,12,7],[12,7,12,-22],[12,-22,-12,-22],[-12,-22,-12,4]];
  for(const [ax,az,bx,bz] of segments){
    const length=Math.hypot(bx-ax,bz-az),steps=Math.floor(length/.34),angle=Math.atan2(bx-ax,bz-az);
    for(let i=0;i<=steps;i++){
      const t=i/steps,x=ax+(bx-ax)*t,z=az+(bz-az)*t;
      if(Math.abs(x-riverX(z))<riverWidth(z)+1.1) continue;
      fencePieces.push([x,heightAt(x,z),z,angle]);
      if(i%8===0) posts.push([x,heightAt(x,z),z,angle]);
    }
    for(let i=0;i<steps;i++){
      const t=(i+.5)/steps,x=ax+(bx-ax)*t,z=az+(bz-az)*t;
      if(Math.abs(x-riverX(z))<riverWidth(z)+1.5)continue;
      for(const y of [.38,.79]){const g=new THREE.BoxGeometry(.07,.08,length/steps+.02);g.rotateY(angle);g.translate(x,heightAt(x,z)+y,z);rails.push(g);}
    }
  }
  const fenceMat=new THREE.MeshStandardMaterial({color:'#eeeede',roughness:.8});
  const pickets=new THREE.InstancedMesh(new THREE.BoxGeometry(.11,.97,.065),fenceMat,fencePieces.length);
  const caps=new THREE.InstancedMesh(new THREE.ConeGeometry(.078,.14,4),fenceMat,fencePieces.length);
  fencePieces.forEach(([x,y,z,a],i)=>{dummy.position.set(x,y+.56,z);dummy.rotation.set(0,a,0);dummy.scale.set(1,1,1);dummy.updateMatrix();pickets.setMatrixAt(i,dummy.matrix);dummy.position.y=y+1.1;dummy.rotation.y=a+Math.PI/4;dummy.updateMatrix();caps.setMatrixAt(i,dummy.matrix);});
  pickets.castShadow=true;scene.add(pickets,caps);
  const fenceRails=new THREE.Mesh(mergeGeometries(rails),fenceMat);fenceRails.castShadow=true;scene.add(fenceRails);rails.forEach(g=>g.dispose());
  const pillar=new THREE.InstancedMesh(new THREE.BoxGeometry(.2,1.25,.2),fenceMat,posts.length);
  posts.forEach(([x,y,z],i)=>{dummy.position.set(x,y+.625,z);dummy.rotation.set(0,0,0);dummy.scale.set(1,1,1);dummy.updateMatrix();pillar.setMatrixAt(i,dummy.matrix);});pillar.castShadow=true;scene.add(pillar);
  colliders.push({minX:-11.3,maxX:-1.55,minZ:6.85,maxZ:7.15},{minX:1.55,maxX:12.2,minZ:6.85,maxZ:7.15},{minX:11.85,maxX:12.15,minZ:-22.2,maxZ:7.15},{minX:-12.15,maxX:12.15,minZ:-22.15,maxZ:-21.85},{minX:-12.15,maxX:-11.85,minZ:-22,maxZ:4});

  const bridgeCenter=riverX(18),bridgeParts=[],wood=new THREE.MeshStandardMaterial({color:'#8f7451',roughness:.89});
  function bridgeBox(w,h,d,x,y,z){let g=new THREE.BoxGeometry(w,h,d);g.translate(x,y,z);bridgeParts.push(g);}
  for(let i=0;i<44;i++){
    const x=bridgeCenter-7.5+i*15/43,y=bridgeHeight(x);
    bridgeBox(.32,.12,2.5,x,y-.06,18);
  }
  for(const z of [16.72,19.28]) {
    for(let i=0;i<9;i++){const x=bridgeCenter-6.9+i*1.725,y=bridgeHeight(x);bridgeBox(.15,1.15,.15,x,y+.55,z);}
    for(let i=0;i<24;i++){
      const x=bridgeCenter-7+i*14/23,y=bridgeHeight(x);
      bridgeBox(.7,.1,.12,x,y+1.03,z);bridgeBox(.7,.065,.09,x,y+.5,z);
    }
    colliders.push({minX:bridgeCenter-7.4,maxX:bridgeCenter+7.4,minZ:z-.12,maxZ:z+.12});
  }
  const bridge=new THREE.Mesh(mergeGeometries(bridgeParts),wood);bridge.castShadow=true;bridge.receiveShadow=true;scene.add(bridge);bridgeParts.forEach(g=>g.dispose());
  function bridgeHeight(x){return .18+.7*Math.sin(clamp((x-(bridgeCenter-7.7))/15.4,0,1)*Math.PI);}
  function walkHeight(x,z){
    if(Math.abs(z-18)<1.3&&Math.abs(x-bridgeCenter)<7.7)return bridgeHeight(x)+.08;
    if(Math.abs(x)<5.65&&z>=-6&&z<-2.05) return z< -2.9?.72:.18+(-z-2.05)/.85*.54;
    return heightAt(x,z);
  }
  function inWater(x,z){return Math.abs(x-riverX(z))<riverWidth(z)+.1&&!(Math.abs(z-18)<1.3&&Math.abs(x-bridgeCenter)<8);}

  return {sky,water,colliders,walkHeight,inWater,bridgeCenter,
    setQuality(high){stream.setQuality(high);},
    setEvening(t){sky.material.color.setRGB(1.-t*.22,1.-t*.37,1.-t*.52);water.material.uniforms.sunColor.value.set('#fff4de').lerp(new THREE.Color('#efc193'),t);},
    update(time){stream.update(time);mist.forEach((m,i)=>{m.position.x+=Math.sin(i+time*.008)*.002;});}
  };
}

function softTexture(){const c=document.createElement('canvas');c.width=c.height=128;const ctx=c.getContext('2d'),g=ctx.createRadialGradient(64,64,0,64,64,64);g.addColorStop(0,'rgba(255,255,255,.8)');g.addColorStop(.4,'rgba(255,255,255,.5)');g.addColorStop(1,'rgba(255,255,255,0)');ctx.fillStyle=g;ctx.fillRect(0,0,128,128);return new THREE.CanvasTexture(c);}
