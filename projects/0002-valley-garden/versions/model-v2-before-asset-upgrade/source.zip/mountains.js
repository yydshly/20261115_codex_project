import * as THREE from 'three';

/** An actual Tyrolean DEM surface, scaled to the miniature valley's art direction. */
export function createMountains(scene,nature){
  const positions=[],uv=[],indices=[],n=256;
  for(let row=0;row<n;row++)for(let col=0;col<n;col++){
    const x=(col/(n-1)-.5)*2300,z=-140-(1-row/(n-1))*2200;
    const distanceFromEdge=(n-1-row)/(n-1);
    const blend=THREE.MathUtils.smoothstep(distanceFromEdge,0,.12);
    const height=Math.max(0,nature.elevation[row*n+col]-676.7)*.245;
    positions.push(x,height*blend-.35,z);uv.push(col/(n-1),row/(n-1));
    if(row<n-1&&col<n-1){const a=row*n+col;indices.push(a,a+n,a+1,a+1,a+n,a+n+1);}
  }
  const geometry=new THREE.BufferGeometry();
  geometry.setAttribute('position',new THREE.Float32BufferAttribute(positions,3));
  geometry.setAttribute('uv',new THREE.Float32BufferAttribute(uv,2));geometry.setIndex(indices);geometry.computeVertexNormals();
  const material=new THREE.MeshStandardMaterial({map:nature.rock.color,roughness:1,side:THREE.DoubleSide});
  material.onBeforeCompile=shader=>{
    shader.uniforms.mountainMeadow={value:nature.aerial};
    shader.vertexShader='varying vec3 mountainPosition; varying vec3 mountainNormal;\n'+shader.vertexShader;
    shader.vertexShader=shader.vertexShader.replace('#include <begin_vertex>','#include <begin_vertex>\nmountainPosition=position; mountainNormal=normal;');
    shader.fragmentShader='uniform sampler2D mountainMeadow; varying vec3 mountainPosition; varying vec3 mountainNormal;\n'+shader.fragmentShader;
    shader.fragmentShader=shader.fragmentShader.replace('#include <map_fragment>',`
      vec3 geologicalNormal=normalize(mountainNormal);
      vec3 weights=pow(abs(geologicalNormal),vec3(5.));weights/=max(dot(weights,vec3(1.)),.001);
      vec3 stone=texture2D(map,mountainPosition.zy*.052).rgb*weights.x
        +texture2D(map,mountainPosition.xz*.052).rgb*weights.y
        +texture2D(map,mountainPosition.xy*.052).rgb*weights.z;
      vec3 grass=texture2D(mountainMeadow,mountainPosition.xz*.008).rgb;
      vec3 broad=texture2D(mountainMeadow,mountainPosition.xz*.00085).rgb;
      float steepness=1.-abs(geologicalNormal.y);
      float exposed=smoothstep(.13,.48,steepness);
      exposed=max(exposed,smoothstep(220.,380.,mountainPosition.y)*.7);
      vec3 forest=grass*vec3(.30,.48,.27)*(.7+broad.g*.7);
      vec3 cliff=stone*vec3(.72,.77,.79);
      diffuseColor.rgb*=mix(forest,cliff,exposed);
    `);
  };
  material.customProgramCacheKey=()=> 'real-kaiser-dem-1';
  const mountain=new THREE.Mesh(geometry,material);mountain.name='Wilder Kaiser real elevation terrain · 130050 triangles';
  scene.add(mountain);
  return mountain;
}
