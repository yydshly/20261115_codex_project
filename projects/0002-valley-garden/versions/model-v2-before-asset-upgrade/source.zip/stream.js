import * as THREE from 'three';
import { Water } from 'three/addons/objects/Water.js';
import { tiledMaterialMaps } from './nature.js';

/** Realtime reflected water over a separate, shadow-receiving gravel stream bed. */
export function createStream(scene,nature,{riverX,riverWidth}){
  const positions=[],uv=[],indices=[],bottom=[],sections=650,across=12;
  for(let i=0;i<=sections;i++){
    const z=-650+i*1000/sections,w=riverWidth(z),cx=riverX(z);
    for(let j=0;j<=across;j++){
      const t=j/across,x=cx+(t*2-1)*w,depth=.08+Math.pow(Math.sin(t*Math.PI),.7)*.88;
      positions.push(x,-z,0);uv.push(t,i/14);
      bottom.push(x,-.05-depth,z);
      if(i<sections&&j<across){const a=i*(across+1)+j;indices.push(a,a+across+1,a+1,a+1,a+across+1,a+across+2);}
    }
  }
  const geometry=new THREE.BufferGeometry();geometry.setAttribute('position',new THREE.Float32BufferAttribute(positions,3));geometry.setAttribute('uv',new THREE.Float32BufferAttribute(uv,2));geometry.setIndex(indices);geometry.computeVertexNormals();
  const bedGeometry=new THREE.BufferGeometry();bedGeometry.setAttribute('position',new THREE.Float32BufferAttribute(bottom,3));
  const bedUv=[];for(let i=0;i<bottom.length;i+=3)bedUv.push(bottom[i]*.65,bottom[i+2]*.65);
  bedGeometry.setAttribute('uv',new THREE.Float32BufferAttribute(bedUv,2));bedGeometry.setIndex(indices);bedGeometry.computeVertexNormals();
  const bed=new THREE.Mesh(bedGeometry,new THREE.MeshStandardMaterial({...tiledMaterialMaps(nature.gravel,1),color:'#8b978b',roughness:1,normalScale:new THREE.Vector2(.65,.65),side:THREE.DoubleSide}));bed.receiveShadow=true;bed.name='Contoured gravel river bed';scene.add(bed);
  const data=new Uint8Array([128,128,255,255]);const normal=new THREE.DataTexture(data,1,1);normal.needsUpdate=true;
  const water=new Water(geometry,{textureWidth:1024,textureHeight:1024,waterNormals:normal,sunDirection:new THREE.Vector3(-48,68,40).normalize(),sunColor:0xfff2dc,waterColor:0x3d7270,distortionScale:.34,fog:true});
  water.name='Flowing stream · reflection, shallow refraction, absorption';water.rotation.x=-Math.PI/2;water.position.y=-.05;
  const material=water.material;material.uniforms.streamBedMap={value:nature.gravel.color};
  material.fragmentShader='uniform sampler2D streamBedMap;\n'+material.fragmentShader;
  const start=material.fragmentShader.indexOf('vec4 getNoise('),end=material.fragmentShader.indexOf('void sunLight(',start);
  material.fragmentShader=material.fragmentShader.slice(0,start)+`
    float channelCenter(float z){return -28.+40.*exp(-pow((z-30.)/22.,2.))+2.*sin(z*.028);}
    vec4 getNoise(vec2 uv){
      float cross=uv.x-channelCenter(uv.y),flow=uv.y+time*.72;
      float a=cross*8.3+flow*4.8+sin(flow*.9),b=cross*15.1-flow*10.7;
      float c=cross*28.+flow*19.3,d=cross*1.7+flow*2.2;
      float dx=cos(a)*.038+cos(b)*.024+cos(c)*.008+cos(d)*.018;
      float dz=cos(a)*.055-cos(b)*.033+cos(c)*.012+cos(d)*.022;
      return vec4(-dx,-dz,1.,1.);
    }
  `+material.fragmentShader.slice(end);
  material.fragmentShader=material.fragmentShader.replace('float rf0 = 0.3;','float rf0 = 0.0204;')
    .replace('100.0, 2.0, 0.5','180.0, 1.05, 0.5')
    .replace('vec3 outgoingLight = albedo;',`
      float width=3.5+.7*sin(worldPosition.z*.025+1.);
      float edge=clamp((width-abs(worldPosition.x-channelCenter(worldPosition.z)))/width,0.,1.);
      float depth=.08+pow(sin(edge*1.570796),.7)*.88;
      vec2 bedUv=worldPosition.xz*.65+surfaceNormal.xz*.18*depth;
      vec3 gravel=texture2D(streamBedMap,bedUv).rgb;
      float caustic=pow(max(0.,1.-abs(sin(worldPosition.x*12.+worldPosition.z*6.+time*2.3)
        +sin(worldPosition.x*7.-worldPosition.z*9.-time*1.7))*.7),9.);
      vec3 transmittance=exp(-vec3(.65,.30,.19)*depth*1.7);
      vec3 bedLight=gravel*vec3(.62,.72,.62)*(1.+caustic*.17)*(.32+.68*getShadowMask());
      vec3 refraction=bedLight*transmittance+vec3(.025,.105,.095)*(1.-transmittance);
      vec3 outgoingLight=mix(refraction,reflectionSample,reflectance)+specularLight*.32;
      float shore=1.-smoothstep(.01,.12,edge);
      float lace=pow(max(0.,sin(worldPosition.z*14.+worldPosition.x*9.+time*3.2)),12.);
      outgoingLight=mix(outgoingLight,vec3(.66,.72,.69),shore*lace*.16);
    `);
  scene.add(water);
  return {water,update(time){material.uniforms.time.value=time;},setQuality(high){material.uniforms.distortionScale.value=high?.34:.22;}};
}
