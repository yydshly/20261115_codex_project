import * as THREE from 'three';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js';
import { foliageLighting } from './lighting.js';
import { groundNoise } from './ground.js';
import { wildnessAt } from './terrain.js';
export const treeWindTime={value:0};

const SOURCES={
  house:'architecture/bungalow-house.glb',
  townhouse:'architecture/two-storey-home.glb',
  cottage:'architecture/garden-cottage.glb',
  daisy:'plants/flower_gazania/model.gltf',
  hedge:'plants/shrub_02/model.gltf',
  matureNear:'trees/jacaranda/leafy-tree-near.gltf',
  matureFar:'trees/jacaranda/leafy-tree-far.gltf',
  matureDistant:'trees/jacaranda/leafy-tree-distant.gltf',
  flower:'plants/periwinkle_plant/model.gltf',
  fern:'plants/fern_02/model.gltf',
  grass:'plants/grass_medium_02/model.gltf',
  lawn:'plants/grass_short/model.gltf',
  meadow:'plants/grass_meadow/model.gltf',
  shrub:'nature/shrub_03/shrub_03_1k.gltf',
  tree:'nature/pine_sapling_small/pine_sapling_small_1k.gltf',
  stone:'nature/rock_07/rock_07_1k.gltf',
  moss:'nature/rock_moss_set_01/rock_moss_set_01_1k.gltf'
};
const OPACITY={
  flower:'plants/periwinkle_plant/textures/periwinkle_plant_opacity_1k.png',
  fern:'plants/fern_02/textures/fern_02_alpha_1k.png',
  grass:'plants/grass_medium_02/textures/grass_medium_02_alpha_1k.png',
  lawn:'plants/grass_medium_02/textures/grass_medium_02_alpha_1k.png',
  meadow:'plants/grass_medium_02/textures/grass_medium_02_alpha_1k.png',
  shrub:'nature/shrub_03/textures/shrub_03_alpha_1k.png',
  tree:'nature/pine_sapling_small/textures/pine_sapling_small_twig_alpha_1k.png',
  daisy:'plants/flower_gazania/textures/opacity_1k.png',
  hedge:'plants/shrub_02/textures/opacity_1k.png'
};

/** Real glTF assets only: each botanical collection becomes independent variants. */
export async function loadModelLibrary(renderer,onProgress=()=>{}){
  const loader=new GLTFLoader(),library={};let loaded=0;
  const treeResponse=await fetch(new URL('./assets/models/trees/jacaranda/manifest.json',import.meta.url));
  if(!treeResponse.ok)throw new Error('成熟树模型元数据加载失败');
  const treeMetadata=await treeResponse.json();
  const coverageRoot=new URL('./assets/models/trees/jacaranda/textures/',import.meta.url);
  const [coverageMetadata,coverageBuffer]=await Promise.all([
    fetch(new URL('leaves-coverage.json',coverageRoot)).then(r=>{if(!r.ok)throw new Error('叶冠蒙版元数据加载失败');return r.json();}),
    fetch(new URL('leaves-coverage.bin',coverageRoot)).then(r=>{if(!r.ok)throw new Error('叶冠蒙版加载失败');return r.arrayBuffer();})
  ]);
  const coverageLevels=coverageMetadata.levels.map(l=>({data:new Uint8Array(coverageBuffer,l.offset,l.bytes),width:l.width,height:l.height}));
  const canopyOpacity=new THREE.DataTexture(coverageLevels[0].data,1024,1024,THREE.RGBAFormat);
  canopyOpacity.mipmaps=coverageLevels;canopyOpacity.generateMipmaps=false;
  canopyOpacity.minFilter=THREE.LinearMipmapLinearFilter;canopyOpacity.magFilter=THREE.LinearFilter;
  canopyOpacity.wrapS=canopyOpacity.wrapT=THREE.RepeatWrapping;canopyOpacity.flipY=false;
  canopyOpacity.colorSpace=THREE.NoColorSpace;canopyOpacity.needsUpdate=true;
  canopyOpacity.anisotropy=Math.min(8,renderer.capabilities.getMaxAnisotropy());
  const surfaces={};
  await Promise.all(['roof','plaster','brick'].map(async name=>{
    const entries=await Promise.all(['color','normal','roughness'].map(async channel=>{
      const map=await new THREE.TextureLoader().loadAsync(new URL(`./assets/materials/${name}-${channel}.jpg`,import.meta.url).href);
      map.colorSpace=channel==='color'?THREE.SRGBColorSpace:THREE.NoColorSpace;
      map.wrapS=map.wrapT=THREE.RepeatWrapping;map.flipY=false;
      map.anisotropy=Math.min(8,renderer.capabilities.getMaxAnisotropy());return [channel,map];
    }));surfaces[name]=Object.fromEntries(entries);
  }));
  await Promise.all(Object.entries(SOURCES).map(async([id,path])=>{
    const gltf=await loader.loadAsync(new URL(`./assets/models/${path}`,import.meta.url).href);
    let opacity=null;
    const opacityPath=OPACITY[id];
    if(id.startsWith('mature'))opacity=canopyOpacity;
    if(opacityPath){
      opacity=await new THREE.TextureLoader().loadAsync(new URL(`./assets/models/${opacityPath}`,import.meta.url).href);
      opacity.colorSpace=THREE.NoColorSpace;opacity.flipY=false;
      opacity.wrapS=opacity.wrapT=THREE.RepeatWrapping;
      opacity.anisotropy=Math.min(8,renderer.capabilities.getMaxAnisotropy());
    }
    gltf.scene.updateMatrixWorld(true);
    const roots=['house','townhouse','cottage'].includes(id)||id.startsWith('mature')?[gltf.scene]:gltf.scene.children;
    library[id]=roots.filter(root=>{let found=false;root.traverse(o=>found ||= !!o.isMesh);return found;})
      .map(root=>prepareVariant(root,id,renderer,opacity,surfaces,treeMetadata));
    library[id].sort((a,b)=>a.triangles-b.triangles);
    if(!library[id].length)throw new Error(`模型 ${id} 没有可显示的网格`);
    onProgress(++loaded,Object.keys(SOURCES).length);
  }));
  // All LODs use the same UV atlases. Share one material/texture set on the GPU.
  const matureMaterials=new Map(library.matureNear[0].parts.map(p=>[p.material.name,p.material]));
  for(const id of ['matureFar','matureDistant'])for(const part of library[id][0].parts){
    const shared=matureMaterials.get(part.material.name);if(!shared)throw new Error('树木 LOD 材质不匹配');
    part.material.dispose();part.material=shared;
  }
  return library;
}

function prepareVariant(root,id,renderer,opacity,surfaces,treeMetadata){
  const bounds=id.startsWith('mature')?new THREE.Box3(new THREE.Vector3(...treeMetadata.sourceBounds.min),new THREE.Vector3(...treeMetadata.sourceBounds.max)):new THREE.Box3().setFromObject(root),size=bounds.getSize(new THREE.Vector3());
  const center=bounds.getCenter(new THREE.Vector3());center.y=bounds.min.y;
  if(id.startsWith('mature'))center.fromArray(treeMetadata.origin);
  const buckets=new Map();let triangles=0;
  root.traverse(object=>{
    if(!object.isMesh)return;
    if(object.isSkinnedMesh)throw new Error('植物资产应为静态网格');
    const input=object.geometry,index=input.index;
    const groups=input.groups.length?input.groups:[{start:0,count:index?index.count:input.attributes.position.count,materialIndex:0}];
    for(const group of groups){
      const sourceMaterial=Array.isArray(object.material)?object.material[group.materialIndex]:object.material;
      if(!buckets.has(sourceMaterial.uuid))buckets.set(sourceMaterial.uuid,{sourceMaterial,geometries:[]});
      const data={position:[],normal:[],uv:[],uv1:[]};
      // GLTFLoader enables USE_COLOR for these materials; dropping COLOR_0 renders them black.
      if(sourceMaterial.vertexColors)data.color=[];
      for(let n=group.start;n<group.start+group.count;n++){
        const v=index?index.getX(n):n;
        for(const [name,components] of [['position',3],['normal',3],['uv',2],['uv1',2]]){
          const attribute=input.getAttribute(name)|| (name==='uv1'?input.getAttribute('uv'):null);
          data[name].push(attribute?attribute.getX(v):0,attribute?attribute.getY(v):0);
          if(components===3)data[name].push(attribute?attribute.getZ(v):(name==='normal'?1:0));
        }
        if(data.color){const attribute=input.getAttribute('color');data.color.push(attribute?attribute.getX(v):1,attribute?attribute.getY(v):1,attribute?attribute.getZ(v):1,attribute?.itemSize===4?attribute.getW(v):1);}
      }
      const geometry=new THREE.BufferGeometry();
      for(const name of Object.keys(data))geometry.setAttribute(name,new THREE.Float32BufferAttribute(data[name],name.startsWith('uv')?2:name==='color'?4:3));
      geometry.applyMatrix4(object.matrixWorld);geometry.translate(-center.x,-center.y,-center.z);
      if(!input.attributes.normal)geometry.computeVertexNormals();
      buckets.get(sourceMaterial.uuid).geometries.push(geometry);triangles+=group.count/3;
    }
  });
  const parts=[];
  for(const {sourceMaterial,geometries} of buckets.values()){
    const material=sourceMaterial.clone(),geometry=mergeGeometries(geometries,false);
    geometries.forEach(g=>g.dispose());
    material.envMapIntensity=.8;
    if(['house','townhouse','cottage'].includes(id)){
      if(/mineral render|white outdoor paint/.test(material.name)){
        material.roughness=.91;material.metalness=0;
        material.bumpMap=material.map;material.bumpScale=/mineral/.test(material.name)?.003:.0007;
        if(material.specularIntensity!==undefined)material.specularIntensity=.25;
      }
      if(/sandstone/.test(material.name)){material.bumpMap=material.map;material.bumpScale=.025;material.roughness=.94;}
      if(/finished oak/.test(material.name)){material.bumpMap=material.map;material.bumpScale=.008;material.roughness=.64;}
      if(/clear glazing/.test(material.name)){material.roughness=.075;material.envMapIntensity=1.25;}
    }
    const masked=id.startsWith('mature')?/leaves/i.test(material.name):id!=='tree'||/twig/i.test(material.name);
    if(opacity&&masked){material.alphaMap=opacity;material.transparent=false;material.depthWrite=true;material.alphaTest=id.startsWith('mature')?.30:.28;material.side=THREE.DoubleSide;}
    for(const key of ['map','normalMap','roughnessMap','metalnessMap','aoMap'])if(material[key])material[key].anisotropy=Math.min(8,renderer.capabilities.getMaxAnisotropy());
    if(material.alphaTest>0){material.alphaToCoverage=false;material.side=THREE.DoubleSide;}
    if(['grass','lawn','meadow'].includes(id)){
      material.roughness=1;material.normalScale?.setScalar(.28);
    }
    // New physical maps are a runtime derivative; the downloaded GLBs stay byte-identical.
    if(['house','townhouse','cottage'].includes(id)){
      const roof=/red clay roof|Clay roof tiles|dark natural slate/i.test(material.name);
      const wall=/mineral render|Render, warm beige/i.test(material.name);
      const brick=/red running-bond brick/i.test(material.name);
      if(roof||wall||brick){
        const maps=surfaces[roof?'roof':brick?'brick':'plaster'];
        material.map=maps.color;material.normalMap=maps.normal;material.roughnessMap=maps.roughness;
        material.bumpMap=null;material.roughness=roof?.88:.96;material.metalness=0;
        material.normalScale.setScalar(roof?.48:brick?.42:.24);material.color.set(roof?'#a3aeb6':brick?'#f2e7dc':'#f5f4ed');
        const p=geometry.attributes.position,n=geometry.attributes.normal,uv=geometry.attributes.uv;
        for(let i=0;i<p.count;i++)uv.setXY(i,roof?p.getX(i)*.4:(Math.abs(n.getX(i))>.5?p.getZ(i):p.getX(i))*.5,roof?-p.getZ(i)*.45:p.getY(i)*.5);
        uv.needsUpdate=true;
      }
    }else{
      material.envMapIntensity=1.;
      material.onBeforeCompile=shader=>{
        if(opacity&&masked){
          shader.uniforms.foliageSunDirection=foliageLighting.direction;
          shader.uniforms.foliageSunColour=foliageLighting.colour;
          shader.uniforms.foliageSunIntensity=foliageLighting.strength;
          shader.fragmentShader='uniform vec3 foliageSunDirection,foliageSunColour; uniform float foliageSunIntensity;\n'+shader.fragmentShader;
          shader.fragmentShader=shader.fragmentShader.replace('#include <lights_fragment_end>',`#include <lights_fragment_end>
            vec3 foliageLightView=normalize(mat3(viewMatrix)*foliageSunDirection);
            float leafTransmission=pow(max(0.,dot(-normal,foliageLightView)),2.);
            reflectedLight.indirectDiffuse+=diffuseColor.rgb*foliageSunColour*(.015+leafTransmission*.025*foliageSunIntensity);
          `);
        }
        if(id.startsWith('mature')){
          shader.uniforms.treeWindTime=treeWindTime;
          shader.vertexShader='uniform float treeWindTime;\n'+shader.vertexShader;
          shader.vertexShader=shader.vertexShader.replace('#include <begin_vertex>',`#include <begin_vertex>
            float treePhase=0.;
            #ifdef USE_INSTANCING
              treePhase=instanceMatrix[3].x*.07+instanceMatrix[3].z*.05;
            #endif
            float canopyWeight=smoothstep(2.,14.,position.y);
            transformed.x+=sin(treeWindTime*.73+position.y*.17+treePhase)*.10*canopyWeight;
            transformed.z+=cos(treeWindTime*.49+position.x*.11+treePhase)*.055*canopyWeight;
          `);
        }
        if(id==='lawn'||id==='meadow'){
          shader.uniforms.treeWindTime=treeWindTime;
          shader.vertexShader='uniform float treeWindTime;\n'+shader.vertexShader;
          shader.vertexShader=shader.vertexShader.replace('#include <begin_vertex>',`#include <begin_vertex>
            float grassPhase=instanceMatrix[3].x*.7+instanceMatrix[3].z*.4;
            transformed.x+=sin(treeWindTime*1.1+grassPhase)*max(position.y,0.)*.08;
          `);
        }
        if(['grass','lawn','meadow'].includes(id))shader.fragmentShader=shader.fragmentShader.replace('#include <roughnessmap_fragment>','#include <roughnessmap_fragment>\nroughnessFactor=max(roughnessFactor,.88);');
      };
      material.customProgramCacheKey=()=> id.startsWith('mature')?'leafy-tree-wind-2':['lawn','meadow'].includes(id)?'matte-grass-wind-2':'soft-botanical-fill-1';
    }
    parts.push({geometry,material});
  }
  return {name:root.name,size,parts,triangles};
}

export function createModelCottage(scene,library,style='house'){
  const model=library[style][0],group=new THREE.Group();group.name=`Imported Innerscene ${style}`;
  group.position.set(0,.18,-9.5);
  for(const part of model.parts){const mesh=new THREE.Mesh(part.geometry,part.material);mesh.castShadow=!(part.material.transmission>0||part.material.transparent);mesh.receiveShadow=true;group.add(mesh);}
  scene.add(group);group.updateMatrixWorld(true);
  const raycaster=new THREE.Raycaster(),down=new THREE.Vector3(0,-1,0),origin=new THREE.Vector3();
  const footprint=new THREE.Box3();
  for(const part of model.parts)if(/mineral render|Render, warm beige|red running-bond brick/i.test(part.material.name)){
    part.geometry.computeBoundingBox();footprint.union(part.geometry.boundingBox);
  }
  if(footprint.isEmpty())throw new Error('建筑缺少可核对的外墙边界');
  const collider={minX:footprint.min.x,maxX:footprint.max.x,minZ:footprint.min.z+group.position.z,maxZ:footprint.max.z+group.position.z};
  return {group,colliders:[collider],walkHeight(x,z){
    if(Math.abs(x)>6.5||z< -16||z> -2.8)return null;
    raycaster.set(origin.set(x,1.35,z),down);
    const hits=raycaster.intersectObject(group,true);
    return hits.length?hits[0].point.y:null;
  }};
}

class ModelBatch{
  constructor(variant){this.variant=variant;this.transforms=[];}
  add(x,y,z,height,angle=0){const scale=height/Math.max(.001,this.variant.size.y);this.transforms.push({x,y,z,scale,angle});}
  finish(parent,{shadow=true}={}){
    if(!this.transforms.length)return;
    const dummy=new THREE.Object3D();
    for(const part of this.variant.parts){
      const mesh=new THREE.InstancedMesh(part.geometry,part.material,this.transforms.length);
      mesh.name=`Imported ${this.variant.name} × ${this.transforms.length}`;mesh.castShadow=shadow;mesh.receiveShadow=true;
      this.transforms.forEach((p,i)=>{dummy.position.set(p.x,p.y,p.z);dummy.rotation.set(0,p.angle,0);dummy.scale.setScalar(p.scale);dummy.updateMatrix();mesh.setMatrixAt(i,dummy.matrix);});
      mesh.computeBoundingSphere();parent.add(mesh);
    }
  }
}

/** Managed short lawn inside the fence, with clustered tall scan meshes outside. */
export function createModelLawn(scene,library,{heightAt,weightsAt,random}){
  const group=new THREE.Group();group.name='Managed lawn and wild meadow';scene.add(group);
  const cells=new Map();let shortCount=0,meadowCount=0;
  function add(kind,x,z,height){
    const key=`${kind}:${Math.floor(x/24)}:${Math.floor(z/24)}`;
    if(!cells.has(key))cells.set(key,{kind,batches:library[kind].map(v=>new ModelBatch(v))});
    const batches=cells.get(key).batches;
    batches[Math.floor(random()*batches.length)].add(x,heightAt(x,z)-.012,z,height,random()*Math.PI*2);
  }
  for(let attempt=0;attempt<60000&&shortCount<3000;attempt++){
    const x=-14+random()*28,z=-25+random()*36;
    if(Math.abs(x)<6.6&&z>-17&&z< -2)continue;
    if(wildnessAt(x,z)>.35||weightsAt(x,z).grass<.86)continue;
    add('lawn',x,z,.045+random()*.06);shortCount++;
  }
  for(let attempt=0;attempt<120000&&meadowCount<10500;attempt++){
    const x=-62+random()*124,z=-85+random()*150,wild=wildnessAt(x,z);
    if(wild<.08||weightsAt(x,z).grass<.86)continue;
    if(Math.abs(z-18)<1.8&&Math.abs(x)<13)continue;
    const cluster=groundNoise(x*.17+6,z*.17+3)*.7+groundNoise(x*.043,z*.043)*.3;
    if(random()>.12+cluster*.85)continue;
    const h=(.12+cluster*.25+random()*.13)*(.4+.6*wild);
    add('meadow',x,z,h);meadowCount++;
  }
  for(const {kind,batches} of cells.values())for(const batch of batches){
    const start=group.children.length;batch.finish(group,{shadow:false});
    for(const mesh of group.children.slice(start)){mesh.userData.grassKind=kind;mesh.userData.fullCount=mesh.count;}
  }
  return {group,count:shortCount+meadowCount,shortCount,meadowCount,setQuality(high){for(const mesh of group.children)mesh.count=Math.floor(mesh.userData.fullCount*(high?1:.4));}};
}

export function createModelGarden(scene,library,{heightAt,riverX,riverWidth,random}){
  const group=new THREE.Group();group.name='Imported botanical and scanned rock models';scene.add(group);
  const contacts=[];
  const batches={};
  for(const id of ['flower','daisy','hedge','fern','grass','shrub','tree','stone','moss'])batches[id]=library[id].map(v=>new ModelBatch(v));
  const pick=id=>{
    // Use full variants near paths, lighter variants for repeated meadow plants.
    const pool=id==='flower'?batches[id].filter(b=>/_0[23]_/.test(b.variant.name)):batches[id],limit=pool.length;
    return pool[Math.floor(random()*limit)];
  };
  function plant(id,x,z,h){
    if(Math.abs(x-riverX(z))<riverWidth(z)+.7)return;
    pick(id).add(x,heightAt(x,z)+.015,z,h,random()*Math.PI*2);
    if(id!=='grass')contacts.push({x,z,radius:id==='hedge'?h*.65:Math.max(.12,h*.32),occlusion:id==='hedge'?.6:.4,soil:id==='hedge'?.7:0,soilRadius:h*.8});
  }
  // Specimen-scale beds: small pink flowers keep their actual leaf/flower proportions.
  for(const side of [-1,1]){
    for(let c=0;c<31;c++)for(let r=0;r<7;r++){
      const x=side*(2.9+c*.245+(random()-.5)*.09),z=5.0+r*.255+(random()-.5)*.13;
      plant('flower',x,z,.55+random()*.24);
    }
    for(let c=0;c<42;c++){
      const z=-19.7+c*.57;
      for(let r=0;r<3;r++)plant('flower',side*(8.1+r*.36+(random()-.5)*.1),z,.55+random()*.25);
      if(c%2===0)plant('shrub',side*(10.65+random()*.25),z,.45+random()*.25);
      if(c%5===0)plant('fern',side*7.45,z+.55,.45+random()*.25);
    }
    for(let i=0;i<20;i++){
      const z=-2.2+i*.43,x=side*(2.1+random()*.5);
      plant(i%4===0?'fern':'flower',x,z,.44+random()*.22);
    }
  }
  for(const side of [-1,1])for(let i=0;i<10;i++)plant('fern',side*(3.2+i*.77),6.6,.45+random()*.18);
  // Mature scan-based shrubs establish the borders; low flowers sit in front of them.
  for(const side of [-1,1]){
    for(let i=0;i<8;i++){
      const x=side*(3.25+i*.99),z=5.15+Math.sin(i*.68)*.26;
      plant('hedge',x,z,.76+random()*.28);
      for(let j=0;j<4;j++)plant('daisy',x+(random()-.5)*.7,z-.65-random()*.48,.24+random()*.12);
    }
    for(let i=0;i<15;i++){
      const z=-21+i*1.65,x=side*(9.65+Math.sin(i*.73)*.28);
      plant('hedge',x,z,.88+random()*.35);
      for(let j=0;j<3;j++)plant('daisy',x-side*(.6+random()*.65),z+(random()-.5)*.9,.25+random()*.12);
    }
    for(let i=0;i<13;i++){
      const z=-1.3+i*.54,x=side*(1.85+Math.sin(i*.64)*.15);
      plant('daisy',x,z,.24+random()*.13);
    }
  }
  for(let i=0;i<12;i++)plant('hedge',-10+i*1.8,-21.2,.85+random()*.30);
  const saplings=[[-14.2,-15,2.8],[14.8,-24,3.3],[-16.5,-28,2.6]];
  for(const [x,z,h] of saplings)plant('tree',x,z,h);
  // Ferns follow the shaded water margins; the centre path and bridge approach stay clear.
  for(let i=0;i<95;i++){
    const z=-40+random()*85,side=i%2?1:-1;
    const x=riverX(z)+side*(riverWidth(z)+.9+random()*1.4);
    if(Math.abs(z-18)<2.1)continue;
    plant(i%3===0?'shrub':'fern',x,z,.28+random()*.36);
  }
  for(let i=0;i<1150;i++){
    const x=-25+random()*52,z=-35+random()*80;
    if((Math.abs(x)<1.65&&z>-3&&z<13)||(Math.abs(x)<7&&z>-16.5&&z< -2)||(z>11&&z<20&&Math.abs(x+(z-12))<2)||(Math.abs(z-18)<2&&Math.abs(x-riverX(z))<9))continue;
    plant('grass',x,z,.12+random()*.15);
  }
  const colliders=saplings.map(([x,z])=>({minX:x-.2,maxX:x+.2,minZ:z-.2,maxZ:z+.2}));
  // Actual scanned rocks, independently recentered from the six-rock source collection.
  for(let i=0;i<67;i++){
    const z=-65+random()*140,side=i%2?1:-1,x=riverX(z)+side*(riverWidth(z)-.25+random()*.8);
    if(Math.abs(z-18)<3)continue;
    const id=i%3?'moss':'stone',h=.15+Math.pow(random(),2)*.6;
    pick(id).add(x,Math.max(-.19,heightAt(x,z))-.04,z,h,random()*6.28);
    contacts.push({x,z,radius:.2+h*.65,occlusion:.6});
    if(h>.55)colliders.push({minX:x-.35,maxX:x+.35,minZ:z-.35,maxZ:z+.35});
  }
  for(const [id,models] of Object.entries(batches))for(const batch of models)batch.finish(group,{shadow:id!=='grass'});
  return {group,colliders,contacts,update(){}};
}
