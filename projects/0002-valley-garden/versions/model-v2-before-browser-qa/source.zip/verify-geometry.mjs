// CPU validation of actual glTF data and scene geometry; it does not claim GPU visual QA.
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import * as THREE from 'three';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
import { loadModelLibrary, createModelCottage, createModelGarden,createModelLawn } from './model-assets.js';
import { createMountains } from './mountains.js';
import { createStream } from './stream.js';
import { createModelWoodland } from './woodland.js';
import { createGroundSurface,createGroundGeometry,createBankGeometry } from './ground.js';
import { createLightingRig,foliageLighting } from './lighting.js';
import { riverX, riverWidth, heightAt, seededRandom } from './landscape.js';
import { setTerrainElevation,meadowHeightAt,meadowSurfaceHeightAt,mountainHeightAt,wildnessAt } from './terrain.js';

const originalFetch=globalThis.fetch;
globalThis.fetch=async (request,options)=>{
  const url=typeof request==='string'?request:request instanceof URL?request.href:request.url;
  if(url.startsWith('file:')){
    const bytes=await readFile(new URL(url));return new Response(bytes,{headers:{'Content-Length':String(bytes.length)}});
  }
  return originalFetch(request,options);
};
globalThis.ProgressEvent=class extends Event{constructor(type,details){super(type);Object.assign(this,details);}};
THREE.TextureLoader.prototype.loadAsync=async()=>new THREE.Texture();
GLTFLoader.prototype.loadAsync=async function(url){
  this.register(()=>({name:'CPUAssetInspection',loadTexture:async()=>new THREE.Texture()}));
  const bytes=await readFile(new URL(url));
  return this.parseAsync(bytes.buffer.slice(bytes.byteOffset,bytes.byteOffset+bytes.byteLength),new URL('.',url).href);
};
const renderer={capabilities:{getMaxAnisotropy:()=>8}};
const models=await loadModelLibrary(renderer);
for(const [name,variants] of Object.entries(models))for(const variant of variants){
  assert(variant.size.y>0&&Number.isFinite(variant.size.y),`${name} has invalid height`);
  for(const part of variant.parts)for(const attr of Object.values(part.geometry.attributes)){
    assert(attr.array.every(Number.isFinite),`${name} contains non-finite vertex data`);
  }
}
const bytes=await readFile(new URL('./assets/terrain/kaiser-height.f32',import.meta.url));
const elevation=new Float32Array(bytes.buffer.slice(bytes.byteOffset,bytes.byteOffset+bytes.byteLength));
setTerrainElevation(elevation);
const scene=new THREE.Scene();
for(const style of ['townhouse','house','cottage']){
  const house=createModelCottage(scene,models,style);
  const collider=house.colliders[0];
  assert(collider.minX<0&&collider.maxX>0&&collider.minZ<collider.maxZ);
  assert(collider.maxZ< -3,`${style} blocks the garden spawn`);
  const glass=models[style][0].parts.find(p=>/glaz/i.test(p.material.name));
  assert(glass?.material.isMeshPhysicalMaterial&&glass.material.transmission>0.8,'Window glass is missing its physical transmission');
  assert(glass.material.ior>1.5&&glass.material.thickness>=.008&&!glass.material.transparent,'Glass is still an alpha-blended hole');
  if(style==='cottage'){
    const {interior}=house;
    assert.equal(models.cottage[0].windows.length,7);
    assert.equal(interior.windowDressings.length,7);
    assert.equal(interior.furniture.length,9);
    house.group.updateMatrixWorld(true);
    for(const item of interior.furniture){
      const box=new THREE.Box3().setFromObject(item).translate(house.group.position.clone().negate());
      assert(box.min.x>= -3.74&&box.max.x<=3.74&&box.min.z>= -5.28&&box.max.z<=4.16,'Imported furniture crosses an exterior wall');
      assert(Math.abs(box.min.y-.363)<.00001,'Imported furniture is not seated on the floor');
    }
    const windowRay=new THREE.Raycaster();
    for(const dressed of interior.windowDressings){
      const centre=new THREE.Vector3().fromArray(dressed.opening.min).add(new THREE.Vector3().fromArray(dressed.opening.max)).multiplyScalar(.5).add(house.group.position);
      const normal=new THREE.Vector3(0,0,1).applyQuaternion(dressed.group.quaternion);
      const right=new THREE.Vector3(1,0,0).applyQuaternion(dressed.group.quaternion);
      let roomHits=0;
      for(const x of [-.22,.22])for(const y of [-.22,.22]){
        const origin=centre.clone().addScaledVector(normal,1).addScaledVector(right,dressed.width*x);origin.y+=dressed.height*y;
        windowRay.set(origin,normal.clone().negate());
        const hits=windowRay.intersectObject(house.group,true);
        assert(hits.some(h=>/glaz/i.test(h.object.material.name)),`${dressed.opening.name} has no glass in its actual opening`);
        if(hits.some(h=>h.object.parent===interior.group))roomHits++;
      }
      assert(roomHits>=2,`${dressed.opening.name} still sees through an empty shell`);
    }
    const dayIntensity=interior.lightSources.map(l=>l.intensity);
    house.setEvening(1);assert(interior.lightSources.every((l,i)=>l.intensity>dayIntensity[i]),'Indoor lights do not follow dusk');
    house.setEvening(0);
    console.log('OK: seven real glazed/dressed windows, furnished rooms, ceiling/partitions and dusk lighting');
  }
  console.log(`${style}: size ${models[style][0].size.toArray().map(x=>x.toFixed(3)).join(' × ')}, wall collider ${JSON.stringify(collider)}`);
}
const garden=createModelGarden(scene,models,{heightAt,riverX,riverWidth,random:seededRandom(5044)});
const scanCount=name=>garden.group.children.filter(o=>o.isInstancedMesh&&o.name.includes(name)).reduce((sum,o)=>sum+o.count,0);
assert(scanCount('shrub_02')>=50,'Mature model borders are missing');
assert(scanCount('flower_gazania')>=140,'Low flowering model borders are missing');
for(const mesh of garden.group.children)if(mesh.isInstancedMesh)assert(mesh.instanceMatrix.array.every(Number.isFinite));
console.log(`OK: planted ${scanCount('shrub_02')} mature shrub and ${scanCount('flower_gazania')} Gazania model instances`);
const woodland=createModelWoodland(scene,models,{heightAt,riverX,random:seededRandom(8266)});
const camera=new THREE.PerspectiveCamera(52,1,.1,2300);camera.position.set(15,14,38);camera.lookAt(0,2,-40);
woodland.update(1,camera);
const levelCounts=()=>[0,1,2].map(level=>woodland.group.children.find(m=>m.name.startsWith(`Mature tree LOD ${level}`)).count);
let levels=levelCounts();assert(levels.reduce((a,b)=>a+b,0)<=548);
assert(levels[0]<=6&&levels[1]<=22&&levels[0]>0);
assert(woodland.foothillCount>=2500,'Wooded foothills are missing');
for(const t of woodland.trees)assert(Math.abs(t.y+.08-heightAt(t.x,t.z))<.00001,'Tree roots missed the shared terrain');
const parts=models.matureNear[0].parts,leaves=parts.find(p=>/leaves/.test(p.material.name));
assert(models.matureNear[0].size.equals(models.matureFar[0].size));
assert(models.matureNear[0].size.equals(models.matureDistant[0].size));
assert.equal(models.matureNear[0].triangles,266394);
assert.equal(models.matureFar[0].triangles,67621);
assert.equal(models.matureDistant[0].triangles,9919);
assert(leaves.material.alphaMap&&leaves.material.alphaTest>0);
assert.equal(leaves.material.alphaMap.mipmaps.length,11,'Coverage-preserving tree alpha mips are missing');
assert(!leaves.material.alphaToCoverage,'Subpixel tree coverage must not be cut twice');
assert(parts.filter(p=>!/leaves/.test(p.material.name)).every(p=>!p.material.alphaMap),'Bark must remain opaque');
assert.equal(models.matureFar[0].parts[0].material,models.matureNear[0].parts[0].material,'Tree LODs should share materials');
camera.position.set(1000,20,1000);camera.lookAt(2000,20,2000);woodland.update(2,camera);levels=levelCounts();
assert.equal(levels.reduce((a,b)=>a+b,0),0,'Out-of-view woodland still consumes the visible tree budget');
camera.position.set(15,14,38);camera.lookAt(0,2,-40);woodland.update(3,camera);
assert(levelCounts()[2]>100,'Distant wooded slopes are not displayed');
camera.lookAt(100,14,100);woodland.update(4,camera);
assert(levelCounts()[2]<100,'Rotating in place failed to update forest visibility');
console.log(`OK: ${woodland.treeCount} mature trees, including ${woodland.foothillCount} on wooded slopes; LOD/view budgets and rotation updates valid`);
const texture=new THREE.Texture(),set={color:texture,normal:texture,roughness:texture};
const nature={elevation,aerial:texture,dryGrass:texture,rock:set,gravel:set,grass:set,soil:set};
const ground=createGroundSurface(nature,{riverX,riverWidth});
ground.setContacts([...garden.contacts,...woodland.contacts],{minX:-4,maxX:4,minZ:-15.06,maxZ:-5.06});
assert(ground.weightsAt(20,20).grass>.95,'Open lawn lost grass coverage');
assert(ground.weightsAt(9.5,4).soil>.5,'Flowerbed soil is missing');
assert(ground.weightsAt(0,5).soil>.5,'Path soil is missing');
const shoreline=ground.weightsAt(riverX(30)+riverWidth(30)+1.4,30);
assert(shoreline.soil>.2&&shoreline.gravel>.1,'Soil/gravel riverbank transition is missing');
assert(ground.contactAt(woodland.contacts[0].x,woodland.contacts[0].z)[0]>.4,'Tree-root contact is missing');
const lawn=createModelLawn(scene,models,{heightAt,weightsAt:ground.weightsAt,random:seededRandom(18274)});
assert.equal(lawn.shortCount,3000);assert.equal(lawn.meadowCount,10500);
for(const mesh of lawn.group.children){
  const matrix=mesh.instanceMatrix.array;
  for(let i=0;i<mesh.count;i++)assert(ground.weightsAt(matrix[i*16+12],matrix[i*16+14]).grass>.85,'A short grass tuft crossed onto exposed soil or water');
}
const shader={uniforms:{},vertexShader:THREE.ShaderLib.standard.vertexShader,fragmentShader:THREE.ShaderLib.standard.fragmentShader};
ground.material.onBeforeCompile(shader);
assert(shader.fragmentShader.includes('float roughnessFactor='),'Ground roughness variable is missing');
assert(shader.fragmentShader.includes('getTangentFrame(-vViewPosition,normal,groundUv)'),'Ground normal UV frame is missing');
assert.equal(shader.uniforms.groundContacts.value,ground.atlas);
assert(shader.fragmentShader.includes('float lawnRoughness=.90+'),'Grass may still use the low-roughness source map directly');
const nearGround=createGroundGeometry(meadowHeightAt),farGround=createGroundGeometry(meadowHeightAt,{near:false});
for(const g of [nearGround,farGround])for(const attr of Object.values(g.attributes))assert(attr.array.every(Number.isFinite));
const farHeights=new Map(),fp=farGround.attributes.position;
for(let i=0;i<fp.count;i++)farHeights.set(`${fp.getX(i)},${fp.getZ(i)}`,fp.getY(i));
const np=nearGround.attributes.position;
for(let i=0;i<np.count;i++){
  const x=np.getX(i),z=np.getZ(i);let expected;
  if(Math.abs(x)===60){const z0=Math.floor(z/5)*5;expected=THREE.MathUtils.lerp(farHeights.get(`${x},${z0}`),farHeights.get(`${x},${z0+5}`),(z-z0)/5);}
  else if(Math.abs(z)===60){const x0=Math.floor(x/5)*5;expected=THREE.MathUtils.lerp(farHeights.get(`${x0},${z}`),farHeights.get(`${x0+5},${z}`),(x-x0)/5);}
  if(expected!==undefined)assert(Math.abs(np.getY(i)-expected)<.00001,'Near/far ground seam opened');
}
const groundRaycaster=new THREE.Raycaster(),nearMesh=new THREE.Mesh(nearGround),farMesh=new THREE.Mesh(farGround);
for(let i=0;i<120;i++){
  const x=-85+(i*31.37)%170,z=-85+(i*23.13)%150;
  groundRaycaster.set(new THREE.Vector3(x,50,z),new THREE.Vector3(0,-1,0));
  const hit=groundRaycaster.intersectObjects([nearMesh,farMesh])[0];
  assert(hit&&Math.abs(hit.point.y-meadowSurfaceHeightAt(x,z))<.0001,'Grass/tree root sampler missed rendered meadow triangles');
}
const bank=createBankGeometry({heightAt:meadowHeightAt,riverX,riverWidth});
for(let i=0;i<bank.attributes.normal.count;i++)assert(bank.attributes.normal.getY(i)>0,'A riverbank face points down and may be culled');
const outerHeights=[];
for(let x=15;x<60;x+=2)for(let z=-50;z<50;z+=2)if(Math.abs(x-riverX(z))>riverWidth(z)+12)outerHeights.push(meadowHeightAt(x,z));
assert(Math.max(...outerHeights)-Math.min(...outerHeights)>2,'The outer meadow is still flat');
assert.equal(wildnessAt(5,0),0);assert.equal(wildnessAt(30,0),1);
console.log(`OK: matte layered ground, contact masks, seams, rolling outer meadow and ${lawn.shortCount}/${lawn.meadowCount} short/wild grass instances`);
const mountain=createMountains(scene,nature);mountain.geometry.computeBoundingBox();
assert.equal(mountain.geometry.index.count/3,130050);
assert(mountain.geometry.boundingBox.max.y>390&&mountain.geometry.boundingBox.max.y<410);
const raycaster=new THREE.Raycaster(),origin=new THREE.Vector3(),down=new THREE.Vector3(0,-1,0);
for(let i=0;i<120;i++){
  const x=-450+(i*197.13)%900,z=-160-(i*119.73)%700;
  raycaster.set(origin.set(x,800,z),down);
  const hit=raycaster.intersectObject(mountain)[0];
  assert(hit&&Math.abs(hit.point.y-mountainHeightAt(x,z))<.001,'DEM sampler differs from the rendered triangles');
}
const cover=mountain.geometry.attributes.forestCover;
assert(cover&&cover.array.some(x=>x>.8),'Forested mountain material coverage is missing');
const stream=createStream(scene,nature,{riverX,riverWidth});
const lightingRenderer={shadowMap:{}},lighting=createLightingRig(scene,lightingRenderer);
lighting.update(1,{water:stream.water,setEvening(){}});
assert(stream.water.material.uniforms.sunDirection.value.equals(foliageLighting.direction.value));
assert(stream.water.material.uniforms.sunColor.value.equals(lighting.sun.color));
assert.equal(lightingRenderer.shadowMap.type,THREE.PCFSoftShadowMap);
assert.equal(lightingRenderer.toneMappingExposure,.92);
assert(stream.water.material.fragmentShader.includes('float rf0 = 0.0204;'));
assert(!stream.water.material.fragmentShader.includes('vec3 outgoingLight = albedo;'));
assert(stream.water.material.fragmentShader.includes('vec2 reflectedUv='),'Reflection filtering patch failed');
assert(stream.water.material.vertexShader.includes('streamCoordinate=uv;'),'Stream UV varying patch failed');
const flowUv=stream.water.geometry.attributes.uv;
assert.equal(flowUv.getY(0),0);assert(flowUv.getY(flowUv.count-1)>1000);
for(let i=13;i<flowUv.count;i+=13)assert(flowUv.getY(i)>flowUv.getY(i-13),'Flow distance must increase downstream');
assert(!stream.water.material.fragmentShader.includes('float a=cross*'),'Old striped sine-wave field still active');
assert(!stream.water.material.fragmentShader.includes('float lace='),'Old periodic foam field still active');
stream.update(8);assert.equal(stream.water.material.uniforms.time.value,8);
for(const mesh of [mountain,stream.water])for(const attr of Object.values(mesh.geometry.attributes))assert(attr.array.every(Number.isFinite));
console.log(`OK: ${Object.keys(models).length} real asset sets loaded, variants finite, building bounds valid, DEM and stream geometry complete (CPU only)`);
