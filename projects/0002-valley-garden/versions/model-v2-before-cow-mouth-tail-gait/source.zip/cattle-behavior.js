import * as THREE from 'three';

const smooth=THREE.MathUtils.smoothstep;
const templates=new WeakMap();
const legs=[
  {x:-.23,hip:.32,knee:.27,foot:.292,phase:.25,bend:1},
  {x:.055,hip:.32,knee:.26,foot:.289,phase:.75,bend:1},
  {x:-.245,hip:-.74,knee:-.84,foot:-.76,phase:0,bend:-1},
  {x:.078,hip:-.65,knee:-.83,foot:-.80,phase:.5,bend:-1}
];

function prepare(source){
  if(templates.has(source))return templates.get(source);
  source.updateMatrixWorld(true);const meshes=[];source.traverse(o=>{if(o.isMesh)meshes.push(o);});
  if(meshes.length!==1)throw new Error('当前奶牛动作需要单一静态网格');
  const input=meshes[0],geometry=input.geometry.clone().applyMatrix4(input.matrixWorld),p=geometry.attributes.position;
  const indices=new Uint16Array(p.count*4),weights=new Float32Array(p.count*4);let muzzle=0,nearest=Infinity;
  for(let i=0;i<p.count;i++){
    const x=p.getX(i),y=p.getY(i),z=p.getZ(i);
    const neck=smooth(z,.36,.63)*smooth(y,.68,.94),head=neck*smooth(z+(y-1)*.60,.66,.84);
    const jaw=head*smooth(z,.85,1.06)*(1-smooth(y,1.015,1.12))*.85;
    const tail=(1-smooth(z,-1.08,-.92))*(1-smooth(Math.abs(x+.075),.07,.14))*(1-smooth(y,.94,1.10));
    const legIndex=(z<-.22?2:0)+(x>-.085?1:0),leg=legs[legIndex];
    const legWeight=(1-smooth(y,.48,.87))*(1-smooth(Math.hypot((x-leg.x)/.22,(z-leg.knee)/.28),.55,1.15));
    const lower=1-smooth(y,.30,.47),hoof=1-smooth(y,.09,.17),base=5+legIndex*3;
    const scores=tail>.05?[[4,tail],[0,1-tail]]:legWeight>.001?[[0,1-legWeight],[base,legWeight*(1-lower)],[base+1,legWeight*lower*(1-hoof)],[base+2,legWeight*lower*hoof]]:[[0,1-neck],[1,neck-head],[2,head-jaw],[3,jaw]];
    scores.forEach(([bone,weight],j)=>{indices[i*4+j]=bone;weights[i*4+j]=weight;});
    // Muzzle support at the grazing skull angle, with the head counter-rotating at the poll.
    const d=y*Math.cos(.80)-z*Math.sin(.80);if(z>.90&&y<1.20&&d<nearest){nearest=d;muzzle=i;}
  }
  geometry.setAttribute('skinIndex',new THREE.Uint16BufferAttribute(indices,4));geometry.setAttribute('skinWeight',new THREE.Float32BufferAttribute(weights,4));
  // Only the fixed torso/legs enter the cached sun map. The moving neck has no stale self-shadow.
  const caster=geometry.clone(),triangles=[],index=geometry.index;
  for(let i=0;i<index.count;i+=3){const a=index.getX(i),b=index.getX(i+1),c=index.getX(i+2);if([a,b,c].every(v=>indices[v*4]===0&&weights[v*4]>.999))triangles.push(a,b,c);}
  caster.setIndex(triangles);
  const template={geometry,caster,material:input.material,muzzle,restMuzzle:new THREE.Vector3().fromBufferAttribute(p,muzzle)};
  templates.set(source,template);return template;
}

/** Runtime armature over the retained static GLB; feet and torso stay planted. */
export function createGrazingCow(source,{phaseOffset=6,animate=true,surfaceHeight}){
  const template=prepare(source),root=new THREE.Group(),body=new THREE.Bone(),neck=new THREE.Bone(),head=new THREE.Bone(),jaw=new THREE.Bone(),tail=new THREE.Bone();
  body.name='Cow fixed body';neck.name='Cow neck';head.name='Cow head';jaw.name='Cow jaw';tail.name='Cow tail';
  neck.position.set(0,.84,.25);head.position.set(.14,.26,.52);jaw.position.set(0,-.10,.25);tail.position.set(-.075,.96,-.94);
  body.add(neck,tail);neck.add(head);head.add(jaw);
  const legBones=legs.map((leg,i)=>{const upper=new THREE.Bone(),lower=new THREE.Bone(),hoof=new THREE.Bone();upper.name=`Cow leg ${i+1} shoulder`;lower.name=`Cow leg ${i+1} knee`;hoof.name=`Cow leg ${i+1} hoof`;upper.position.set(leg.x,.83,leg.hip);lower.position.set(0,-.43,leg.knee-leg.hip);hoof.position.set(0,-.36,leg.foot-leg.knee);body.add(upper);upper.add(lower);lower.add(hoof);return {upper,lower,hoof,leg};});
  const mesh=new THREE.SkinnedMesh(template.geometry,template.material);mesh.name='Cow · grazing head and articulated four-beat walk';mesh.add(body);mesh.bind(new THREE.Skeleton([body,neck,head,jaw,tail,...legBones.flatMap(l=>[l.upper,l.lower,l.hoof])]));mesh.castShadow=false;mesh.receiveShadow=true;mesh.frustumCulled=false;root.add(mesh);
  const shadow=new THREE.Mesh(template.caster,new THREE.MeshBasicMaterial({colorWrite:false,depthWrite:false}));shadow.name='Cow fixed torso shadow';shadow.castShadow=true;shadow.userData.shadowOnly=true;root.add(shadow);
  const point=new THREE.Vector3(),footTarget=new THREE.Vector3(),scale=new THREE.Vector3();
  const state={phase:'grazing',graze:1,muzzleClearance:0,jaw:0,tail:0};
  function pose(graze,time,moving){
    // Rotate fixed-length cervical/skull segments. Do not translate the neck to chase the ground.
    neck.rotation.set(graze*1.10,moving?Math.sin(time*.41+phaseOffset)*.015:0,0);
    head.rotation.set(-graze*.30,moving?Math.sin(time*.37+phaseOffset)*(.015+.06*(1-graze)):0,0);
    state.jaw=moving?(Math.sin(time*5.8+phaseOffset)*.025+.015)*(graze*.75+.25):0;
    jaw.rotation.set(state.jaw,0,moving?Math.sin(time*6.3+phaseOffset)*.012:0);
    state.tail=moving?Math.sin(time*1.13+phaseOffset)*(.12+.16*Math.max(0,Math.sin(time*.17+phaseOffset))):0;tail.rotation.z=state.tail;
    root.updateWorldMatrix(true,false);root.updateMatrixWorld(true);
  }
  function walk(motion){
    const blend=motion?.walkBlend||0;body.position.y=blend*(-.028+Math.sin((motion?.gaitDistance||0)/.56*Math.PI*4)*.006);
    mesh.getWorldScale(scale);
    for(const {upper,lower,hoof,leg}of legBones){
      upper.rotation.x=lower.rotation.x=hoof.rotation.x=0;if(!blend)continue;
      const phase=((motion.gaitDistance/.56+leg.phase)%1+1)%1,stance=.65,u=phase<stance?phase/stance:(phase-stance)/(1-stance);
      const swing=THREE.MathUtils.smoothstep(u,0,1),tangent=-.36*(1-stance)/stance;
      const stride=phase<stance?.18-.36*u:-.18+.36*swing+tangent*(2*u*u*u-3*u*u+u),lift=phase<stance?0:Math.sin(Math.PI*u)**2*.065;
      const underHip=leg.foot<-.7?(leg.hip-leg.foot)*.30:0;
      footTarget.set(leg.x,.04+lift,leg.foot+stride+underHip).applyMatrix4(mesh.matrixWorld);
      footTarget.y=surfaceHeight(footTarget.x,footTarget.z)+.005+(.04+lift)*scale.y;mesh.worldToLocal(footTarget);
      const dy=footTarget.y-upper.position.y-body.position.y,dz=footTarget.z-leg.hip,l1=lower.position.length(),l2=hoof.position.length(),distance=THREE.MathUtils.clamp(Math.hypot(dy,dz),.1,l1+l2-.001);
      const direction=Math.atan2(-dz,-dy),a=Math.acos(THREE.MathUtils.clamp((l1*l1+distance*distance-l2*l2)/(2*l1*distance),-1,1)),b=Math.acos(THREE.MathUtils.clamp((l1*l1+l2*l2-distance*distance)/(2*l1*l2),-1,1));
      const top=direction-leg.bend*a,bottom=top+leg.bend*(Math.PI-b),restTop=Math.atan2(-lower.position.z,-lower.position.y),restBottom=Math.atan2(-hoof.position.z,-hoof.position.y);
      upper.rotation.x=(top-restTop)*blend;lower.rotation.x=(bottom-restBottom-(top-restTop))*blend;hoof.rotation.x=-upper.rotation.x-lower.rotation.x;
    }
    root.updateMatrixWorld(true);
  }
  function update(time,motion){
    const phase=animate?(time+phaseOffset)%38:6;
    const graze=motion?.graze??(phase<20?1:phase<23?1-smooth(phase,20,23):phase<28?0:phase<31?smooth(phase,28,31):1);
    state.phase=motion?.phase||(phase<20||phase>=31?'grazing':phase<23?'raising':phase<28?'looking':'lowering');state.graze=graze;state.speed=motion?.speed||0;state.walkBlend=motion?.walkBlend||0;
    pose(graze,time,animate);walk(motion);mesh.getVertexPosition(template.muzzle,point).applyMatrix4(mesh.matrixWorld);
    state.muzzleClearance=point.y-surfaceHeight(point.x,point.z);
  }
  return {root,mesh,shadow,state,update,legBones,muzzleIndex:template.muzzle,feedingPoint(){body.position.y=0;walk(null);pose(1,0,false);mesh.getVertexPosition(template.muzzle,point).applyMatrix4(mesh.matrixWorld);return point.clone();}};
}
