import * as THREE from 'three';

export const foliageLighting={
  direction:{value:new THREE.Vector3(-48,65,40).normalize()},
  colour:{value:new THREE.Color('#fff1d8')},
  strength:{value:2.8}
};

/** One lighting state drives the scene, water highlights and leaf backlighting. */
export function createLightingRig(scene,renderer){
  renderer.shadowMap.type=THREE.PCFSoftShadowMap;
  const sun=new THREE.DirectionalLight('#fff1d8',2.8);sun.castShadow=true;
  Object.assign(sun.shadow.camera,{left:-33,right:33,top:33,bottom:-33,near:1,far:180});
  sun.shadow.mapSize.set(2048,2048);sun.shadow.normalBias=.018;sun.shadow.bias=-.00006;
  sun.target.position.set(0,0,-8);scene.add(sun,sun.target);
  const ambient=new THREE.HemisphereLight('#cedfe7','#6d6753',.5);scene.add(ambient);
  const fill=new THREE.DirectionalLight('#d4e2e8',.1);fill.position.set(40,28,-60);scene.add(fill);
  const daySun=new THREE.Color('#fff1d8'),eveningSun=new THREE.Color('#ffbd7f');
  const dayFog=new THREE.Color('#bbcdd1'),eveningFog=new THREE.Color('#b6a99e');
  function update(t,landscape){
    sun.position.set(-48,65-t*37,32-t*10);sun.color.copy(daySun).lerp(eveningSun,t);sun.intensity=2.8-t*1.25;
    ambient.intensity=.5-t*.16;fill.intensity=.1-t*.035;
    scene.environmentIntensity=.62-t*.25;renderer.toneMappingExposure=1.-t*.08;
    if(scene.fog)scene.fog.color.copy(dayFog).lerp(eveningFog,t);
    foliageLighting.direction.value.copy(sun.position).sub(sun.target.position).normalize();
    foliageLighting.colour.value.copy(sun.color);foliageLighting.strength.value=sun.intensity;
    if(landscape){
      landscape.setEvening(t);
      landscape.water.material.uniforms.sunDirection.value.copy(foliageLighting.direction.value);
      landscape.water.material.uniforms.sunColor.value.copy(sun.color);
    }
  }
  update(0);return {sun,ambient,fill,update,setQuality(high){
    const size=high?2048:1024;sun.shadow.mapSize.set(size,size);
    sun.shadow.map?.setSize(size,size);sun.shadow.needsUpdate=true;
  }};
}
