import * as THREE from 'three';
import { groundNoise } from './ground.js';
import { treeWindTime } from './model-assets.js';
import { foliageLighting } from './lighting.js';

/** Small solid blades complement the scan tufts at walking distance. */
export function createFineGrass(scene,{heightAt,weightsAt,random}){
  const group=new THREE.Group();group.name='Close lawn blade volume';group.userData.omitFromReflection=true;scene.add(group);
  const positions=[],uv=[],indices=[];
  for(let row=0;row<=3;row++){
    const t=row/3,width=row===3?0:.07*(.6+.4*Math.sin(t*Math.PI));
    for(const side of [-1,1]){positions.push(side*width*.5,t,t*t*.65);uv.push((side+1)/2,t);}
    if(row<3){const a=row*2;indices.push(a,a+1,a+2,a+1,a+3,a+2);}
  }
  const geometry=new THREE.BufferGeometry();geometry.setAttribute('position',new THREE.Float32BufferAttribute(positions,3));geometry.setAttribute('uv',new THREE.Float32BufferAttribute(uv,2));geometry.setIndex(indices);geometry.computeVertexNormals();
  const material=new THREE.MeshStandardMaterial({color:'#728b42',roughness:.95,metalness:0,side:THREE.DoubleSide,envMapIntensity:.55});
  material.onBeforeCompile=shader=>{
    shader.uniforms.fineGrassTime=treeWindTime;
    shader.uniforms.fineGrassSun=foliageLighting.direction;
    shader.vertexShader='uniform float fineGrassTime; varying vec3 fineGrassWorld; varying float grassTip;\n'+shader.vertexShader;
    shader.vertexShader=shader.vertexShader.replace('#include <begin_vertex>',`#include <begin_vertex>
      grassTip=position.y;
      transformed.x+=sin(fineGrassTime*1.1+instanceMatrix[3].x*.7+instanceMatrix[3].z*.4)*position.y*position.y*.10;
      fineGrassWorld=(modelMatrix*instanceMatrix*vec4(transformed,1.)).xyz;
    `);
    shader.fragmentShader='uniform vec3 fineGrassSun; varying vec3 fineGrassWorld; varying float grassTip;\n'+shader.fragmentShader;
    shader.fragmentShader=shader.fragmentShader.replace('#include <color_fragment>',`#include <color_fragment>
      float grassDistance=length(cameraPosition.xz-fineGrassWorld.xz);
      if(grassDistance>19.)discard;
      diffuseColor.rgb*=mix(.58,1.,grassTip);
    `);
    shader.fragmentShader=shader.fragmentShader.replace('#include <lights_fragment_end>',`#include <lights_fragment_end>
      float grassTransmission=pow(max(0.,dot(-normal,normalize(mat3(viewMatrix)*fineGrassSun))),1.5);
      reflectedLight.indirectDiffuse+=diffuseColor.rgb*(.055+grassTransmission*.18);
    `);
  };
  material.customProgramCacheKey=()=> 'near-solid-lawn-blades-1';
  const dummy=new THREE.Object3D(),colour=new THREE.Color(),heightCache=new Map();let count=0,high=true;
  function gridHeight(ix,iz){const key=`${ix},${iz}`;if(!heightCache.has(key))heightCache.set(key,heightAt(ix*.5,iz*.5));return heightCache.get(key);}
  function rootHeight(x,z){
    const ix=Math.floor(x*2),iz=Math.floor(z*2),u=x*2-ix,v=z*2-iz;
    const a=gridHeight(ix,iz),b=gridHeight(ix+1,iz),c=gridHeight(ix,iz+1),d=gridHeight(ix+1,iz+1);
    return u+v<=1?a+(b-a)*u+(c-a)*v:d+(c-d)*(1-u)+(b-d)*(1-v);
  }
  for(let cx=-12;cx<12;cx+=6)for(let cz=-24;cz<12;cz+=6){
    const transforms=[],colours=[];
    for(let i=0;i<32400;i++){
      const x=cx+random()*6,z=cz+random()*6;
      if(Math.abs(x)<4.22&&z>-15.22&&z< -4.84)continue;
      if(Math.abs(x)<1.3&&z>-5.1&&z< -2.45)continue;
      if(weightsAt(x,z).grass<.9)continue;
      const edge=Math.min(x+12,12-x,z+24,12-z);
      if(random()>THREE.MathUtils.smoothstep(edge,0,2.2)*(.65+.35*groundNoise(x*.8,z*.8)))continue;
      const h=.045+Math.pow(random(),.6)*.10,variation=.72+groundNoise(x*.18,z*.18)*.4;
      transforms.push([x,rootHeight(x,z)-.006,z,h,random()*Math.PI*2,(random()-.5)*.6,(random()-.5)*.6]);colours.push(variation);
    }
    if(!transforms.length)continue;
    const mesh=new THREE.InstancedMesh(geometry,material,transforms.length);mesh.name='Near grass blades';mesh.castShadow=false;mesh.receiveShadow=true;
    transforms.forEach(([x,y,z,h,angle,leanX,leanZ],i)=>{dummy.position.set(x,y,z);dummy.rotation.set(leanX,angle,leanZ);dummy.scale.set(h,h,h);dummy.updateMatrix();mesh.setMatrixAt(i,dummy.matrix);mesh.setColorAt(i,colour.setRGB(colours[i],colours[i],colours[i]));});
    mesh.computeBoundingSphere();mesh.userData.fullCount=mesh.count;group.add(mesh);count+=mesh.count;
  }
  return {group,count,update(camera){for(const mesh of group.children){
    const distance=Math.max(0,mesh.boundingSphere.center.distanceTo(camera.position)-mesh.boundingSphere.radius);
    mesh.visible=distance<(high?19:14);mesh.count=Math.floor(mesh.userData.fullCount*(high?1:.48));
  }},setQuality(value){high=value;}};
}
