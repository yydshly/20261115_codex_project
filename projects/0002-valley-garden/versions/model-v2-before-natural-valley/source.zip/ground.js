import * as THREE from 'three';

const clamp=THREE.MathUtils.clamp;
const smooth=(a,b,x)=>{const t=clamp((x-a)/(b-a),0,1);return t*t*(3-2*t);};
export function groundNoise(x,z){
  const ix=Math.floor(x),iz=Math.floor(z),fx=smooth(0,1,x-ix),fz=smooth(0,1,z-iz);
  const h=(a,b)=>{const n=Math.sin(a*127.1+b*311.7)*43758.5453;return n-Math.floor(n);};
  return THREE.MathUtils.lerp(THREE.MathUtils.lerp(h(ix,iz),h(ix+1,iz),fx),THREE.MathUtils.lerp(h(ix,iz+1),h(ix+1,iz+1),fx),fz);
}

/** Shared world-space grass/soil/gravel layers and a sparse, object-derived contact atlas. */
export function createGroundSurface(nature,{riverX,riverWidth}){
  const size=1024,extent=160,data=new Uint8Array(size*size*2);
  const atlas=new THREE.DataTexture(data,size,size,THREE.RGFormat);atlas.magFilter=atlas.minFilter=THREE.LinearFilter;atlas.needsUpdate=true;
  const foundation=new THREE.Vector4(-4,4,-15.06,-5.06);
  function paint(bounds,coverage){
    const px=x=>clamp(Math.floor((x/extent+.5)*size),0,size-1);
    for(let row=px(bounds[2]);row<=px(bounds[3]);row++)for(let col=px(bounds[0]);col<=px(bounds[1]);col++){
      const x=((col+.5)/size-.5)*extent,z=((row+.5)/size-.5)*extent,[ao,soil]=coverage(x,z);
      const offset=(row*size+col)*2;
      for(const [channel,value] of [[0,ao],[1,soil]])data[offset+channel]=Math.round(255*(1-(1-data[offset+channel]/255)*(1-clamp(value,0,1))));
    }
  }
  function bed(minX,maxX,minZ,maxZ){
    paint([minX-.7,maxX+.7,minZ-.7,maxZ+.7],(x,z)=>{
      const dx=Math.max(minX-x,0,x-maxX),dz=Math.max(minZ-z,0,z-maxZ);
      return [0,.76*(1-smooth(0,.65,Math.hypot(dx,dz)))];
    });
  }
  function setContacts(contacts,box){
    data.fill(0);
    for(const side of [-1,1]){
      bed(side<0?-11:2.7,side<0?-2.7:11,4.8,6.7);
      bed(side<0?-11:8,side<0?-8:11,-21.4,4.8);
    }
    bed(-10.7,10.7,-22.4,-20.3);
    for(const c of contacts){
      const radius=Math.max(c.radius,c.soilRadius||0);
      if(Math.abs(c.x)>extent/2+radius||Math.abs(c.z)>extent/2+radius)continue;
      paint([c.x-radius,c.x+radius,c.z-radius,c.z+radius],(x,z)=>{
        const d=Math.hypot(x-c.x,z-c.z);
        return [(c.occlusion??.5)*(1-smooth(0,c.radius,d)),c.soil?(c.soil)*(1-smooth(0,c.soilRadius||c.radius,d)):0];
      });
    }
    if(box)foundation.set(box.minX,box.maxX,box.minZ,box.maxZ);
    atlas.needsUpdate=true;
  }
  function contactAt(x,z){
    const u=(x/extent+.5)*size-.5,v=(z/extent+.5)*size-.5;
    if(u<0||v<0||u>size-1||v>size-1)return [0,0];
    const x0=Math.floor(u),z0=Math.floor(v),tx=u-x0,tz=v-z0,result=[];
    for(let c=0;c<2;c++){
      const at=(a,b)=>data[(Math.min(size-1,b)*size+Math.min(size-1,a))*2+c]/255;
      result.push(THREE.MathUtils.lerp(THREE.MathUtils.lerp(at(x0,z0),at(x0+1,z0),tx),THREE.MathUtils.lerp(at(x0,z0+1),at(x0+1,z0+1),tx),tz));
    }
    return result;
  }
  function weightsAt(x,z){
    const edge=Math.abs(x-riverX(z))-riverWidth(z),gravel=1-smooth(.15,2.3,edge);
    const path=1-smooth(.75,1.4,Math.abs(x));
    const pathRange=smooth(-4,-2.8,z)*(1-smooth(11,12.5,z));
    const bankSoil=smooth(.35,1.1,edge)*(1-smooth(1.7,2.9,edge))*.8;
    const soil=Math.max(contactAt(x,z)[1],path*pathRange*.65,bankSoil)*(1-gravel);
    return {grass:1-gravel-soil,soil,gravel};
  }
  const material=new THREE.MeshStandardMaterial({map:nature.grass.color,normalMap:nature.grass.normal,roughnessMap:nature.grass.roughness,normalScale:new THREE.Vector2(.38,.38),roughness:1});
  material.onBeforeCompile=shader=>{
    Object.assign(shader.uniforms,{groundSoilColor:{value:nature.soil.color},groundSoilNormal:{value:nature.soil.normal},groundSoilRough:{value:nature.soil.roughness},groundGravelColor:{value:nature.gravel.color},groundGravelNormal:{value:nature.gravel.normal},groundGravelRough:{value:nature.gravel.roughness},groundContacts:{value:atlas},groundFoundation:{value:foundation}});
    shader.vertexShader='varying vec3 groundPosition;\n'+shader.vertexShader;
    shader.vertexShader=shader.vertexShader.replace('#include <begin_vertex>','#include <begin_vertex>\ngroundPosition=(modelMatrix*vec4(transformed,1.)).xyz;');
    shader.fragmentShader=`
      varying vec3 groundPosition;
      uniform sampler2D groundSoilColor,groundSoilNormal,groundSoilRough;
      uniform sampler2D groundGravelColor,groundGravelNormal,groundGravelRough,groundContacts;
      uniform vec4 groundFoundation;
      float groundHash(vec2 p){return fract(sin(dot(p,vec2(127.1,311.7)))*43758.5453);}
      float groundNoise(vec2 p){vec2 i=floor(p),f=fract(p);f=f*f*(3.-2.*f);return mix(mix(groundHash(i),groundHash(i+vec2(1.,0.)),f.x),mix(groundHash(i+vec2(0.,1.)),groundHash(i+1.),f.x),f.y);}
    `+shader.fragmentShader;
    shader.fragmentShader=shader.fragmentShader.replace('#include <map_fragment>',`
      vec2 groundUv=groundPosition.xz/1.4;
      vec2 soilUv=groundPosition.xz/1.3;
      vec2 gravelUv=groundPosition.xz*.65;
      vec2 contactUv=groundPosition.xz/160.+.5;
      float inAtlas=step(0.,contactUv.x)*step(contactUv.x,1.)*step(0.,contactUv.y)*step(contactUv.y,1.);
      vec2 contact=texture2D(groundContacts,contactUv).rg*inAtlas;
      float centre=-28.+40.*exp(-pow((groundPosition.z-30.)/22.,2.))+2.*sin(groundPosition.z*.028);
      float width=3.5+.7*sin(groundPosition.z*.025+1.);
      float bankDistance=abs(groundPosition.x-centre)-width;
      float boundaryNoise=(groundNoise(groundPosition.xz*1.1)-.5)*.45;
      float gravelWeight=1.-smoothstep(.15,2.3,bankDistance+boundaryNoise);
      float pathWeight=(1.-smoothstep(.75,1.4,abs(groundPosition.x)))*smoothstep(-4.,-2.8,groundPosition.z)*(1.-smoothstep(11.,12.5,groundPosition.z));
      float bankSoil=smoothstep(.35,1.1,bankDistance)*(1.-smoothstep(1.7,2.9,bankDistance))*.8;
      float soilWeight=max(max(contact.g,pathWeight*.65),bankSoil)*(1.-gravelWeight);
      vec3 groundWeights=vec3(1.-gravelWeight-soilWeight,soilWeight,gravelWeight);
      float wetness=(1.-smoothstep(-.05,.8,bankDistance))*(1.-smoothstep(.18,.4,groundPosition.y));
      float variation=.93+groundNoise(groundPosition.xz*.085)*.13;
      vec3 lawn=texture2D(map,groundUv).rgb*variation;
      vec3 soilColor=texture2D(groundSoilColor,soilUv).rgb;
      vec3 gravelColor=texture2D(groundGravelColor,gravelUv).rgb;
      diffuseColor.rgb*=(lawn*groundWeights.x+soilColor*groundWeights.y+gravelColor*groundWeights.z)*mix(1.,.67,wetness);
      vec2 boxCentre=vec2((groundFoundation.x+groundFoundation.y)*.5,(groundFoundation.z+groundFoundation.w)*.5);
      vec2 boxHalf=vec2(groundFoundation.y-groundFoundation.x,groundFoundation.w-groundFoundation.z)*.5;
      vec2 q=abs(groundPosition.xz-boxCentre)-boxHalf;
      float wallDistance=length(max(q,0.))+min(max(q.x,q.y),0.);
      float groundOcclusion=max(contact.r,exp(-max(wallDistance,0.)/.24)*.72);
    `);
    shader.fragmentShader=shader.fragmentShader.replace('#include <roughnessmap_fragment>',`
      float groundRoughness=texture2D(roughnessMap,groundUv).g*groundWeights.x+texture2D(groundSoilRough,soilUv).g*groundWeights.y+texture2D(groundGravelRough,gravelUv).g*groundWeights.z;
      float roughnessFactor=roughness*mix(groundRoughness,.43,wetness*.65);
    `);
    shader.fragmentShader=shader.fragmentShader.replace('#include <normal_fragment_maps>',`
      vec3 groundNormal=(texture2D(normalMap,groundUv).xyz*2.-1.)*groundWeights.x
        +(texture2D(groundSoilNormal,soilUv).xyz*2.-1.)*groundWeights.y
        +(texture2D(groundGravelNormal,gravelUv).xyz*2.-1.)*groundWeights.z;
      groundNormal.xy*=normalScale;
      normal=normalize(getTangentFrame(-vViewPosition,normal,groundUv)*normalize(groundNormal));
    `);
    shader.fragmentShader=shader.fragmentShader.replace('#include <lights_fragment_end>','#include <lights_fragment_end>\nreflectedLight.indirectDiffuse*=1.-groundOcclusion*.28;');
  };
  material.customProgramCacheKey=()=> 'layered-ground-contact-1';
  setContacts([]);
  return {material,atlas,setContacts,contactAt,weightsAt,foundation};
}

export function createGroundGeometry(heightAt,{near=true}={}){
  const geometry=new THREE.PlaneGeometry(near?120:1100,near?120:1100,near?240:220,near?240:220);
  geometry.rotateX(-Math.PI/2);const p=geometry.attributes.position;
  for(let i=0;i<p.count;i++){
    const x=p.getX(i),z=p.getZ(i)+(near?0:-150);let y=heightAt(x,z);
    if(near){
      const gx=Math.floor(x/5)*5,gz=Math.floor(z/5)*5,tx=(x-gx)/5,tz=(z-gz)/5;
      const coarse=THREE.MathUtils.lerp(THREE.MathUtils.lerp(heightAt(gx,gz),heightAt(gx+5,gz),tx),THREE.MathUtils.lerp(heightAt(gx,gz+5),heightAt(gx+5,gz+5),tx),tz);
      y=THREE.MathUtils.lerp(coarse,y,smooth(0,5,60-Math.max(Math.abs(x),Math.abs(z))));
    }
    p.setXYZ(i,x,y,z);
  }
  if(!near){
    const keep=[],index=geometry.index.array;
    for(let i=0;i<index.length;i+=3){
      const ids=[index[i],index[i+1],index[i+2]],x=ids.reduce((s,id)=>s+p.getX(id),0)/3,z=ids.reduce((s,id)=>s+p.getZ(id),0)/3;
      if(Math.abs(x)<60&&Math.abs(z)<60)continue;keep.push(...ids);
    }
    geometry.setIndex(keep);
  }
  geometry.computeVertexNormals();return geometry;
}

export function createBankGeometry({heightAt,riverX,riverWidth}){
  const positions=[],uv=[],indices=[];
  for(const side of [-1,1]){
    const offset=positions.length/3;
    for(let i=0;i<=650;i++){
      const z=-650+i*1000/650,w=riverWidth(z),cx=riverX(z);
      for(const [d,h] of [[w-.08,-.09],[w+.95,.14],[w+2.5,null]]){
        const x=cx+side*d;positions.push(x,h??heightAt(x,z)+.012,z);uv.push(x*.32,z*.32);
      }
      if(i<650){
        const a=offset+i*3,triangles=[a,a+3,a+1,a+1,a+3,a+4,a+1,a+4,a+2,a+2,a+4,a+5];
        for(let t=0;t<triangles.length;t+=3)indices.push(triangles[t],triangles[t+(side>0?1:2)],triangles[t+(side>0?2:1)]);
      }
    }
  }
  const geometry=new THREE.BufferGeometry();geometry.setAttribute('position',new THREE.Float32BufferAttribute(positions,3));geometry.setAttribute('uv',new THREE.Float32BufferAttribute(uv,2));geometry.setIndex(indices);geometry.computeVertexNormals();return geometry;
}
