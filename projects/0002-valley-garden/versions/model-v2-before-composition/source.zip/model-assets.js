import * as THREE from 'three';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js';

const SOURCES={
  house:'architecture/bungalow-house.glb',
  townhouse:'architecture/two-storey-home.glb',
  flower:'plants/periwinkle_plant/model.gltf',
  fern:'plants/fern_02/model.gltf',
  grass:'plants/grass_medium_02/model.gltf',
  shrub:'nature/shrub_03/shrub_03_1k.gltf',
  tree:'nature/pine_sapling_small/pine_sapling_small_1k.gltf',
  stone:'nature/rock_07/rock_07_1k.gltf',
  moss:'nature/rock_moss_set_01/rock_moss_set_01_1k.gltf'
};
const OPACITY={
  flower:'plants/periwinkle_plant/textures/periwinkle_plant_opacity_1k.png',
  fern:'plants/fern_02/textures/fern_02_alpha_1k.png',
  grass:'plants/grass_medium_02/textures/grass_medium_02_alpha_1k.png',
  shrub:'nature/shrub_03/textures/shrub_03_alpha_1k.png',
  tree:'nature/pine_sapling_small/textures/pine_sapling_small_twig_alpha_1k.png'
};

/** Real glTF assets only: each botanical collection becomes independent variants. */
export async function loadModelLibrary(renderer,onProgress=()=>{}){
  const loader=new GLTFLoader(),library={};let loaded=0;
  const surfaces={};
  await Promise.all(['roof','plaster'].map(async name=>{
    const entries=await Promise.all(['color','normal','roughness'].map(async channel=>{
      const map=await new THREE.TextureLoader().loadAsync(new URL(`./assets/materials/${name}-${channel}.jpg`,import.meta.url).href);
      map.colorSpace=channel==='color'?THREE.SRGBColorSpace:THREE.NoColorSpace;
      map.wrapS=map.wrapT=THREE.RepeatWrapping;map.flipY=false;
      map.anisotropy=Math.min(8,renderer.capabilities.getMaxAnisotropy());return [channel,map];
    }));surfaces[name]=Object.fromEntries(entries);
  }));
  await Promise.all(Object.entries(SOURCES).map(async([id,path])=>{
    const gltf=await loader.loadAsync(new URL(`./assets/models/${path}`,import.meta.url).href);
    let opacity=null;
    if(OPACITY[id]){
      opacity=await new THREE.TextureLoader().loadAsync(new URL(`./assets/models/${OPACITY[id]}`,import.meta.url).href);
      opacity.colorSpace=THREE.NoColorSpace;opacity.flipY=false;
      opacity.anisotropy=Math.min(8,renderer.capabilities.getMaxAnisotropy());
    }
    gltf.scene.updateMatrixWorld(true);
    const roots=['house','townhouse'].includes(id)?[gltf.scene]:gltf.scene.children;
    library[id]=roots.filter(root=>{let found=false;root.traverse(o=>found ||= !!o.isMesh);return found;})
      .map(root=>prepareVariant(root,id,renderer,opacity,surfaces));
    library[id].sort((a,b)=>a.triangles-b.triangles);
    if(!library[id].length)throw new Error(`模型 ${id} 没有可显示的网格`);
    onProgress(++loaded,Object.keys(SOURCES).length);
  }));
  return library;
}

function prepareVariant(root,id,renderer,opacity,surfaces){
  const bounds=new THREE.Box3().setFromObject(root),size=bounds.getSize(new THREE.Vector3());
  const center=bounds.getCenter(new THREE.Vector3());center.y=bounds.min.y;
  const buckets=new Map();let triangles=0;
  root.traverse(object=>{
    if(!object.isMesh)return;
    if(object.isSkinnedMesh)throw new Error('植物资产应为静态网格');
    const input=object.geometry,index=input.index;
    const groups=input.groups.length?input.groups:[{start:0,count:index?index.count:input.attributes.position.count,materialIndex:0}];
    for(const group of groups){
      const sourceMaterial=Array.isArray(object.material)?object.material[group.materialIndex]:object.material;
      if(!buckets.has(sourceMaterial.uuid))buckets.set(sourceMaterial.uuid,{sourceMaterial,geometries:[]});
      const data={position:[],normal:[],uv:[],uv1:[]};
      // GLTFLoader enables USE_COLOR for these materials; dropping COLOR_0 renders them black.
      if(sourceMaterial.vertexColors)data.color=[];
      for(let n=group.start;n<group.start+group.count;n++){
        const v=index?index.getX(n):n;
        for(const [name,components] of [['position',3],['normal',3],['uv',2],['uv1',2]]){
          const attribute=input.getAttribute(name)|| (name==='uv1'?input.getAttribute('uv'):null);
          data[name].push(attribute?attribute.getX(v):0,attribute?attribute.getY(v):0);
          if(components===3)data[name].push(attribute?attribute.getZ(v):(name==='normal'?1:0));
        }
        if(data.color){const attribute=input.getAttribute('color');data.color.push(attribute?attribute.getX(v):1,attribute?attribute.getY(v):1,attribute?attribute.getZ(v):1,attribute?.itemSize===4?attribute.getW(v):1);}
      }
      const geometry=new THREE.BufferGeometry();
      for(const name of Object.keys(data))geometry.setAttribute(name,new THREE.Float32BufferAttribute(data[name],name.startsWith('uv')?2:name==='color'?4:3));
      geometry.applyMatrix4(object.matrixWorld);geometry.translate(-center.x,-center.y,-center.z);
      if(!input.attributes.normal)geometry.computeVertexNormals();
      buckets.get(sourceMaterial.uuid).geometries.push(geometry);triangles+=group.count/3;
    }
  });
  const parts=[];
  for(const {sourceMaterial,geometries} of buckets.values()){
    const material=sourceMaterial.clone(),geometry=mergeGeometries(geometries,false);
    geometries.forEach(g=>g.dispose());
    material.envMapIntensity=.8;
    if(['house','townhouse'].includes(id)){
      if(/mineral render|white outdoor paint/.test(material.name)){
        material.roughness=.91;material.metalness=0;
        material.bumpMap=material.map;material.bumpScale=/mineral/.test(material.name)?.003:.0007;
        if(material.specularIntensity!==undefined)material.specularIntensity=.25;
      }
      if(/sandstone/.test(material.name)){material.bumpMap=material.map;material.bumpScale=.025;material.roughness=.94;}
      if(/finished oak/.test(material.name)){material.bumpMap=material.map;material.bumpScale=.008;material.roughness=.64;}
      if(/clear glazing/.test(material.name)){material.roughness=.075;material.envMapIntensity=1.25;}
    }
    if(opacity&&(id!=='tree'||/twig/i.test(material.name))){material.alphaMap=opacity;material.transparent=false;material.depthWrite=true;material.alphaTest=.35;material.side=THREE.DoubleSide;}
    for(const key of ['map','normalMap','roughnessMap','metalnessMap','aoMap'])if(material[key])material[key].anisotropy=Math.min(8,renderer.capabilities.getMaxAnisotropy());
    if(material.alphaTest>0){material.alphaToCoverage=true;material.side=THREE.DoubleSide;}
    // New physical maps are a runtime derivative; the downloaded GLBs stay byte-identical.
    if(['house','townhouse'].includes(id)){
      const roof=/red clay roof|Clay roof tiles/i.test(material.name);
      const wall=/mineral render|Render, warm beige/i.test(material.name);
      if(roof||wall){
        const maps=surfaces[roof?'roof':'plaster'];
        material.map=maps.color;material.normalMap=maps.normal;material.roughnessMap=maps.roughness;
        material.bumpMap=null;material.roughness=roof?.88:.96;material.metalness=0;
        material.normalScale.setScalar(roof?.55:.24);material.color.set(roof?'#657b91':'#f5f4ed');
        const p=geometry.attributes.position,n=geometry.attributes.normal,uv=geometry.attributes.uv;
        for(let i=0;i<p.count;i++)uv.setXY(i,roof?p.getX(i)*.4:(Math.abs(n.getX(i))>.5?p.getZ(i):p.getX(i))*.5,roof?-p.getZ(i)*.45:p.getY(i)*.5);
        uv.needsUpdate=true;
      }
    }else{
      material.envMapIntensity=1.;
      material.onBeforeCompile=shader=>{shader.fragmentShader=shader.fragmentShader.replace('#include <lights_fragment_end>','#include <lights_fragment_end>\nreflectedLight.indirectDiffuse += diffuseColor.rgb * .055;');};
      material.customProgramCacheKey=()=> 'soft-botanical-fill-1';
    }
    parts.push({geometry,material});
  }
  return {name:root.name,size,parts,triangles};
}

export function createModelCottage(scene,library,style='house'){
  const model=library[style][0],group=new THREE.Group();group.name=`Imported Innerscene ${style}`;
  group.position.set(0,.18,-9.5);
  for(const part of model.parts){const mesh=new THREE.Mesh(part.geometry,part.material);mesh.castShadow=!(part.material.transmission>0||part.material.transparent);mesh.receiveShadow=true;group.add(mesh);}
  scene.add(group);group.updateMatrixWorld(true);
  const raycaster=new THREE.Raycaster(),down=new THREE.Vector3(0,-1,0),origin=new THREE.Vector3();
  const footprint=new THREE.Box3();
  for(const part of model.parts)if(/mineral render|Render, warm beige/i.test(part.material.name)){
    part.geometry.computeBoundingBox();footprint.union(part.geometry.boundingBox);
  }
  if(footprint.isEmpty())throw new Error('建筑缺少可核对的外墙边界');
  const collider={minX:footprint.min.x,maxX:footprint.max.x,minZ:footprint.min.z+group.position.z,maxZ:footprint.max.z+group.position.z};
  return {group,colliders:[collider],walkHeight(x,z){
    if(Math.abs(x)>6.5||z< -16||z> -2.8)return null;
    raycaster.set(origin.set(x,1.35,z),down);
    const hits=raycaster.intersectObject(group,true);
    return hits.length?hits[0].point.y:null;
  }};
}

class ModelBatch{
  constructor(variant){this.variant=variant;this.transforms=[];}
  add(x,y,z,height,angle=0){const scale=height/Math.max(.001,this.variant.size.y);this.transforms.push({x,y,z,scale,angle});}
  finish(parent,{shadow=true}={}){
    if(!this.transforms.length)return;
    const dummy=new THREE.Object3D();
    for(const part of this.variant.parts){
      const mesh=new THREE.InstancedMesh(part.geometry,part.material,this.transforms.length);
      mesh.name=`Imported ${this.variant.name} × ${this.transforms.length}`;mesh.castShadow=shadow;mesh.receiveShadow=true;
      this.transforms.forEach((p,i)=>{dummy.position.set(p.x,p.y,p.z);dummy.rotation.set(0,p.angle,0);dummy.scale.setScalar(p.scale);dummy.updateMatrix();mesh.setMatrixAt(i,dummy.matrix);});
      mesh.computeBoundingSphere();parent.add(mesh);
    }
  }
}

export function createModelGarden(scene,library,{heightAt,riverX,riverWidth,random}){
  const group=new THREE.Group();group.name='Imported botanical and scanned rock models';scene.add(group);
  const batches={};
  for(const id of ['flower','fern','grass','shrub','tree','stone','moss'])batches[id]=library[id].map(v=>new ModelBatch(v));
  const pick=id=>{
    // Use full variants near paths, lighter variants for repeated meadow plants.
    const pool=id==='flower'?batches[id].filter(b=>/_0[23]_/.test(b.variant.name)):batches[id],limit=pool.length;
    return pool[Math.floor(random()*limit)];
  };
  function plant(id,x,z,h){
    if(Math.abs(x-riverX(z))<riverWidth(z)+.7)return;
    pick(id).add(x,heightAt(x,z)+.015,z,h,random()*Math.PI*2);
  }
  // Specimen-scale beds: small pink flowers keep their actual leaf/flower proportions.
  for(const side of [-1,1]){
    for(let c=0;c<31;c++)for(let r=0;r<7;r++){
      const x=side*(2.9+c*.245+(random()-.5)*.09),z=5.0+r*.255+(random()-.5)*.13;
      plant('flower',x,z,.55+random()*.24);
    }
    for(let c=0;c<42;c++){
      const z=-19.7+c*.57;
      for(let r=0;r<3;r++)plant('flower',side*(8.1+r*.36+(random()-.5)*.1),z,.55+random()*.25);
      if(c%2===0)plant('shrub',side*(10.65+random()*.25),z,.45+random()*.25);
      if(c%5===0)plant('fern',side*7.45,z+.55,.45+random()*.25);
    }
    for(let i=0;i<20;i++){
      const z=-2.2+i*.43,x=side*(2.1+random()*.5);
      plant(i%4===0?'fern':'flower',x,z,.44+random()*.22);
    }
  }
  for(const side of [-1,1])for(let i=0;i<10;i++)plant('fern',side*(3.2+i*.77),6.6,.45+random()*.18);
  for(const [x,z,h] of [[-8.5,-1,2.8],[9.7,-17.5,3.3],[-10.4,-20,2.6]])plant('tree',x,z,h);
  // Ferns follow the shaded water margins; the centre path and bridge approach stay clear.
  for(let i=0;i<95;i++){
    const z=-40+random()*85,side=i%2?1:-1;
    const x=riverX(z)+side*(riverWidth(z)+.9+random()*1.4);
    if(Math.abs(z-18)<2.1)continue;
    plant(i%3===0?'shrub':'fern',x,z,.28+random()*.36);
  }
  for(let i=0;i<1150;i++){
    const x=-25+random()*52,z=-35+random()*80;
    if((Math.abs(x)<1.65&&z>-3&&z<13)||(Math.abs(x)<7&&z>-16.5&&z< -2)||(z>11&&z<20&&Math.abs(x+(z-12))<2)||(Math.abs(z-18)<2&&Math.abs(x-riverX(z))<9))continue;
    plant('grass',x,z,.12+random()*.15);
  }
  const colliders=[{minX:-8.7,maxX:-8.3,minZ:-1.2,maxZ:-.8},{minX:9.5,maxX:9.9,minZ:-17.7,maxZ:-17.3}];
  // Actual scanned rocks, independently recentered from the six-rock source collection.
  for(let i=0;i<67;i++){
    const z=-65+random()*140,side=i%2?1:-1,x=riverX(z)+side*(riverWidth(z)-.25+random()*.8);
    if(Math.abs(z-18)<3)continue;
    const id=i%3?'moss':'stone',h=.15+Math.pow(random(),2)*.6;
    pick(id).add(x,Math.max(-.19,heightAt(x,z))-.04,z,h,random()*6.28);
    if(h>.55)colliders.push({minX:x-.35,maxX:x+.35,minZ:z-.35,maxZ:z+.35});
  }
  for(const [id,models] of Object.entries(batches))for(const batch of models)batch.finish(group,{shadow:id!=='grass'});
  return {group,colliders,update(){}};
}
