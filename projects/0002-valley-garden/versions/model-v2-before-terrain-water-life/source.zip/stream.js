import * as THREE from 'three';
import { Water } from 'three/addons/objects/Water.js';
import { tiledMaterialMaps } from './nature.js';
import { budgetReflections } from './reflection-budget.js';

/** Realtime reflected water over a separate, shadow-receiving gravel stream bed. */
export function createStream(scene,nature,{riverX,riverWidth}){
  const positions=[],uv=[],indices=[],bottom=[],sections=650,across=12;
  let arcLength=0,previousZ=-650,previousX=riverX(previousZ);
  for(let i=0;i<=sections;i++){
    const z=-650+i*1000/sections,w=riverWidth(z),cx=riverX(z);
    if(i)arcLength+=Math.hypot(z-previousZ,cx-previousX);
    previousZ=z;previousX=cx;
    for(let j=0;j<=across;j++){
      const t=j/across,x=cx+(t*2-1)*w,depth=.08+Math.pow(Math.sin(t*Math.PI),.7)*.88;
      // Metres across the channel, and cumulative centre-line arc length downstream.
      positions.push(x,-z,0);uv.push((t*2-1)*w,arcLength);
      bottom.push(x,-.05-depth,z);
      if(i<sections&&j<across){const a=i*(across+1)+j;indices.push(a,a+across+1,a+1,a+1,a+across+1,a+across+2);}
    }
  }
  const geometry=new THREE.BufferGeometry();geometry.setAttribute('position',new THREE.Float32BufferAttribute(positions,3));geometry.setAttribute('uv',new THREE.Float32BufferAttribute(uv,2));geometry.setIndex(indices);geometry.computeVertexNormals();
  const bedGeometry=new THREE.BufferGeometry();bedGeometry.setAttribute('position',new THREE.Float32BufferAttribute(bottom,3));
  const bedUv=[];for(let i=0;i<bottom.length;i+=3)bedUv.push(bottom[i]*.65,bottom[i+2]*.65);
  bedGeometry.setAttribute('uv',new THREE.Float32BufferAttribute(bedUv,2));bedGeometry.setIndex(indices);bedGeometry.computeVertexNormals();
  const bed=new THREE.Mesh(bedGeometry,new THREE.MeshStandardMaterial({...tiledMaterialMaps(nature.gravel,1),color:'#8b978b',roughness:1,normalScale:new THREE.Vector2(.65,.65),side:THREE.DoubleSide}));bed.receiveShadow=true;bed.name='Contoured gravel river bed';scene.add(bed);
  const data=new Uint8Array([128,128,255,255]);const normal=new THREE.DataTexture(data,1,1);normal.needsUpdate=true;
  const water=new Water(geometry,{textureWidth:512,textureHeight:512,waterNormals:normal,sunDirection:new THREE.Vector3(-48,68,40).normalize(),sunColor:0xfff2dc,waterColor:0x3d7270,distortionScale:.68,fog:true});
  water.name='Flowing stream · reflection, shallow refraction, absorption';water.rotation.x=-Math.PI/2;water.position.y=-.05;
  const material=water.material;material.uniforms.streamBedMap={value:nature.gravel.color};
  material.vertexShader='varying vec2 streamCoordinate;\n'+material.vertexShader;
  material.vertexShader=material.vertexShader.replace('mirrorCoord = modelMatrix * vec4( position, 1.0 );','streamCoordinate=uv;\nmirrorCoord = modelMatrix * vec4( position, 1.0 );');
  material.fragmentShader='uniform sampler2D streamBedMap; varying vec2 streamCoordinate;\n'+material.fragmentShader;
  const start=material.fragmentShader.indexOf('vec4 getNoise('),end=material.fragmentShader.indexOf('void sunLight(',start);
  material.fragmentShader=material.fragmentShader.slice(0,start)+`
    float channelCenter(float z){return -28.+40.*exp(-pow((z-30.)/22.,2.))+2.*sin(z*.028);}
    // Small multipliers retain float precision along the kilometre-scale arc UV.
    float flowHash(vec2 p){vec3 h=fract(vec3(p.xyx)*vec3(.1031,.1030,.0973));h+=dot(h,h.yzx+33.33);return fract((h.x+h.y)*h.z);}
    float flowNoise(vec2 p){
      vec2 i=floor(p),f=fract(p);f=f*f*(3.-2.*f);
      return mix(mix(flowHash(i),flowHash(i+vec2(1.,0.)),f.x),mix(flowHash(i+vec2(0.,1.)),flowHash(i+1.),f.x),f.y);
    }
    float flowHeight(vec2 p){
      p+=vec2(flowNoise(p*.27+8.1),flowNoise(p*.19-3.7))*.63;
      mat2 rotation=mat2(.83,-.56,.56,.83);
      return (flowNoise(p*vec2(2.8,1.45))-.5)*.014
        +(flowNoise(rotation*p*5.1)-.5)*.006
        +(flowNoise(rotation*p*11.7+17.)-.5)*.002;
    }
    vec4 getNoise(vec2 ignored){
      float width=3.5+.7*sin(worldPosition.z*.025+1.);
      float centre=1.-clamp(abs(streamCoordinate.x)/width,0.,1.);
      // Bounded shear avoids stretching cross-channel wavelengths forever.
      float shear=sin(time*.23)*centre*.34;
      vec2 p=streamCoordinate-vec2(0.,time*.48+shear);
      float epsilon=.035;
      float dx=(flowHeight(p+vec2(epsilon,0.))-flowHeight(p-vec2(epsilon,0.)))/(2.*epsilon);
      float dy=(flowHeight(p+vec2(0.,epsilon))-flowHeight(p-vec2(0.,epsilon)))/(2.*epsilon);
      float z=worldPosition.z;
      float slope=-80.*(z-30.)/(22.*22.)*exp(-pow((z-30.)/22.,2.))+.056*cos(z*.028);
      vec2 tangent=normalize(vec2(slope,1.)),across=vec2(tangent.y,-tangent.x);
      vec2 gradient=across*dx+tangent*dy;
      return vec4(-gradient.x,-gradient.y,1.,1.);
    }
  `+material.fragmentShader.slice(end);
  material.fragmentShader=material.fragmentShader.replace('float rf0 = 0.3;','float rf0 = 0.0204;')
    .replace('100.0, 2.0, 0.5','180.0, 1.05, 0.5')
    .replace('vec3 outgoingLight = albedo;',`
      float width=3.5+.7*sin(worldPosition.z*.025+1.);
      float edge=clamp((width-abs(worldPosition.x-channelCenter(worldPosition.z)))/width,0.,1.);
      float depth=.08+pow(sin(edge*1.570796),.7)*.88;
      vec2 bedUv=worldPosition.xz*.65+surfaceNormal.xz*.18*depth;
      vec3 gravel=texture2D(streamBedMap,bedUv).rgb;
      vec2 moving=streamCoordinate-vec2(0.,time*.57);
      float caustic=pow(1.-abs(flowNoise(moving*4.4+surfaceNormal.xz*.3)*2.-1.),16.);
      vec3 transmittance=exp(-vec3(.65,.30,.19)*depth*1.7);
      vec3 bedLight=gravel*vec3(.72,.79,.70)*(1.+caustic*.12)*(.4+.6*getShadowMask());
      vec3 refraction=bedLight*transmittance+vec3(.025,.105,.095)*(1.-transmittance);
      vec3 outgoingLight=mix(refraction,reflectionSample,reflectance)+specularLight*.32;
      float shore=1.-smoothstep(.01,.12,edge);
      float patches=smoothstep(.64,.84,flowNoise(moving*vec2(6.2,2.1)));
      outgoingLight=mix(outgoingLight,vec3(.66,.72,.69),shore*patches*.12);
    `);
  material.fragmentShader=material.fragmentShader.replace(/vec3 reflectionSample = vec3\( texture2D\( mirrorSampler, mirrorCoord.xy \/ mirrorCoord.w \+ distortion \) \);/,`
    vec2 reflectedUv=mirrorCoord.xy/mirrorCoord.w+distortion;
    vec3 reflectionSample=texture2D(mirrorSampler,reflectedUv).rgb*.5;
    reflectionSample+=(texture2D(mirrorSampler,reflectedUv+vec2(.0007,0.)).rgb
      +texture2D(mirrorSampler,reflectedUv-vec2(.0007,0.)).rgb
      +texture2D(mirrorSampler,reflectedUv+vec2(0.,.0007)).rgb
      +texture2D(mirrorSampler,reflectedUv-vec2(0.,.0007)).rgb)*.125;
  `);
  scene.add(water);
  const reflectionBudget=budgetReflections(water,scene);
  return {water,update(time){material.uniforms.time.value=time;},setQuality(high){reflectionBudget.setQuality(high);material.uniforms.distortionScale.value=high?.68:.42;}};
}
