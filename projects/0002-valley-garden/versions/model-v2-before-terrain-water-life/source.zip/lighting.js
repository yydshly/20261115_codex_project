import * as THREE from 'three';

export const foliageLighting={
  direction:{value:new THREE.Vector3(-48,65,40).normalize()},
  colour:{value:new THREE.Color('#fff4e6')},
  strength:{value:2.35}
};

/** One lighting state drives the scene, water highlights and leaf backlighting. */
export function createLightingRig(scene,renderer){
  renderer.shadowMap.type=THREE.PCFSoftShadowMap;
  const sun=new THREE.DirectionalLight('#fff4e6',2.35);sun.castShadow=true;
  Object.assign(sun.shadow.camera,{left:-33,right:33,top:33,bottom:-33,near:1,far:180});
  sun.shadow.mapSize.set(2048,2048);sun.shadow.normalBias=.007;sun.shadow.bias=-.000025;
  sun.shadow.autoUpdate=false;sun.shadow.needsUpdate=true;
  sun.target.position.set(0,0,-8);scene.add(sun,sun.target);
  const ambient=new THREE.HemisphereLight('#d6e2e9','#625c46',.36);scene.add(ambient);
  const fill=new THREE.DirectionalLight('#d4e2e8',.06);fill.position.set(40,28,-60);scene.add(fill);
  const daySun=new THREE.Color('#fff4e6'),eveningSun=new THREE.Color('#ffca95');
  const dayFog=new THREE.Color('#bbcdd1'),eveningFog=new THREE.Color('#b6a99e');
  let lastShadowLight=-Infinity;
  const shadowEye=new THREE.Vector3(Infinity,0,0),shadowRotation=new THREE.Quaternion();
  const shadowCentre=new THREE.Vector3(),lookAhead=new THREE.Vector3();
  function update(t,landscape,camera){
    // Keep the detailed sun shadow around the walker, with extra room ahead.
    // Moving light and target together preserves the valley's lighting direction.
    if(camera){
      lookAhead.set(0,0,-1).applyQuaternion(camera.quaternion);lookAhead.y=0;lookAhead.normalize();
      shadowCentre.copy(camera.position).addScaledVector(lookAhead,10);shadowCentre.y=camera.position.y-1.7;
      shadowCentre.set(Math.round(shadowCentre.x/2)*2,Math.round(shadowCentre.y/2)*2,Math.round(shadowCentre.z/2)*2);
    }else shadowCentre.set(0,0,-8);
    const shifted=!sun.target.position.equals(shadowCentre);
    sun.target.position.copy(shadowCentre);
    if(shifted||Math.abs(t-lastShadowLight)>.005||(camera&&(camera.position.distanceToSquared(shadowEye)>.8**2||camera.quaternion.angleTo(shadowRotation)>.12))){
      sun.shadow.needsUpdate=true;lastShadowLight=t;
      if(camera){shadowEye.copy(camera.position);shadowRotation.copy(camera.quaternion);}
    }
    sun.position.set(-48,65-t*37,40-t*10).add(shadowCentre);sun.color.copy(daySun).lerp(eveningSun,t);sun.intensity=2.35-t*1.00;
    ambient.intensity=.36-t*.10;fill.intensity=.06-t*.02;
    scene.environmentIntensity=.65-t*.25;renderer.toneMappingExposure=.98-t*.06;
    if(scene.fog)scene.fog.color.copy(dayFog).lerp(eveningFog,t);
    foliageLighting.direction.value.copy(sun.position).sub(sun.target.position).normalize();
    foliageLighting.colour.value.copy(sun.color);foliageLighting.strength.value=sun.intensity;
    if(landscape){
      landscape.setEvening(t);
      landscape.water.material.uniforms.sunDirection.value.copy(foliageLighting.direction.value);
      landscape.water.material.uniforms.sunColor.value.copy(sun.color);
    }
  }
  update(0);return {sun,ambient,fill,update,invalidateShadows(){sun.shadow.needsUpdate=true;},setQuality(high){
    const size=high?2048:1024;sun.shadow.mapSize.set(size,size);
    sun.shadow.map?.setSize(size,size);sun.shadow.needsUpdate=true;
  }};
}
