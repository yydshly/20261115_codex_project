import { streamBedProfileAt } from './stream-profile.js';

export function streamSurfaceOffset(z,side,time){
  const riffle=streamBedProfileAt(z,side*.5+.5).riffle,fade=Math.max(0,1-side*side);
  return fade*(.45+.55*riffle)*(Math.sin(z*1.15-time*2.1+side*2.3)*.006+Math.sin(z*2.55-time*4.4-side*3.1)*.0035);
}

export const streamSurfaceGLSL=`
  float movingSurface(float z,float side,float clock,float riffle){
    return max(0.,1.-side*side)*(.45+.55*riffle)*(sin(z*1.15-clock*2.1+side*2.3)*.006+sin(z*2.55-clock*4.4-side*3.1)*.0035);
  }
`;

/** Travel time along the actual curved centreline; shallow riffles carry faster surface flow. */
export function createStreamFlow(riverX,riverWidth){
  const rows=[];let seconds=0,previous=null,obstacles=[];
  const speed=(z,side=0)=>(.62+streamBedProfileAt(z,.5).riffle*.42)*(1-.55*side*side);
  for(let z=-80;z<=90.001;z+=.25){
    const x=riverX(z);if(previous)seconds+=Math.hypot(x-previous.x,z-previous.z)/speed((z+previous.z)*.5);
    const row={x,z,seconds};rows.push(row);previous=row;
  }
  function timeAtZ(z){
    const f=Math.max(0,Math.min(rows.length-1,(z+80)*4)),i=Math.min(rows.length-2,Math.floor(f));
    return rows[i].seconds+(rows[i+1].seconds-rows[i].seconds)*(f-i);
  }
  function sample(clock,side,out={}){
    const t=((clock%seconds)+seconds)%seconds;let low=0,high=rows.length-1;
    while(high-low>1){const mid=(low+high)>>1;if(rows[mid].seconds<t)low=mid;else high=mid;}
    const a=rows[low],b=rows[high],f=(t-a.seconds)/(b.seconds-a.seconds),dz=b.z-a.z,dx=b.x-a.x,length=Math.hypot(dx,dz);
    let z=a.z+f*dz,x=riverX(z)+side*riverWidth(z);const tx=dx/length,tz=dz/length;
    for(const rock of obstacles){
      if(Math.abs(z-rock.z)>rock.radius*3+1)continue;
      const along=(x-rock.x)*tx+(z-rock.z)*tz,cross=(x-rock.x)*tz-(z-rock.z)*tx;
      const desired=rock.radius*1.35,push=Math.max(0,desired-Math.abs(cross))*Math.exp(-along*along/(desired*desired*2.4))*(cross<0?-1:1);
      x+=tz*push;z-=tx*push;
    }
    const width=riverWidth(z),centre=riverX(z);x=Math.max(centre-width*.88,Math.min(centre+width*.88,x));
    return Object.assign(out,{x,z,side:(x-centre)/width,tx,tz,speed:speed(z,side)});
  }
  return {sample,speed,timeAtZ,duration:seconds,setObstacles(value){obstacles=value;}};
}
