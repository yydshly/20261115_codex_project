import * as THREE from 'three';

const tau=Math.PI*2,angleDelta=(a,b)=>Math.atan2(Math.sin(b-a),Math.cos(b-a));
function seeded(seed){return ()=>{seed|=0;seed=seed+0x6D2B79F5|0;let v=Math.imul(seed^seed>>>15,1|seed);v^=v+Math.imul(v^v>>>7,61|v);return ((v^v>>>14)>>>0)/4294967296;};}

/** Repeatable random grazing stops, with every connecting segment checked before use. */
export function createCowRoaming({x,z,heading,isSafe,seed=41,phaseOffset=0}){
  const random=seeded(seed),radius=4.6,stops=[{x,z,heading}],stages=[];let duration=0,distance=0;
  function lineSafe(a,b){for(let i=0;i<=24;i++){const t=i/24;if(!isSafe(THREE.MathUtils.lerp(a.x,b.x,t),THREE.MathUtils.lerp(a.z,b.z,t)))return false;}return true;}
  for(let i=0;i<700&&stops.length<6;i++){
    const a=random()*tau,r=1.6+random()*2.7,p={x:x+Math.sin(a)*r,z:z+Math.cos(a)*r,heading:random()*tau};
    if(stops.some(q=>Math.hypot(p.x-q.x,p.z-q.z)<1.3)||!lineSafe(stops[0],p))continue;
    if(!isSafe(p.x+Math.sin(p.heading),p.z+Math.cos(p.heading)))continue;stops.push(p);
  }
  function add(kind,seconds,data){stages.push({kind,start:duration,end:duration+seconds,distance,...data});duration+=seconds;}
  function turn(point,from,to){const delta=angleDelta(from,to),seconds=Math.max(1.0,Math.abs(delta)/.65);add('turning',seconds,{point,from,to:from+delta,travel:Math.abs(delta)*.30});distance+=Math.abs(delta)*.30;}
  let current=stops[0];
  for(let leg=0;leg<18;leg++){
    add('grazing',leg===0?16:22+random()*15,{point:current});
    add('raising',1.6,{point:current});
    const choices=stops.filter(p=>p!==current&&lineSafe(current,p)),next=leg===17?stops[0]:choices[Math.floor(random()*choices.length)]||stops[0];
    const length=Math.hypot(next.x-current.x,next.z-current.z),bearing=Math.atan2(next.x-current.x,next.z-current.z);
    turn(current,current.heading,bearing);
    if(length>.05){add('walking',length/.42+.8,{from:current,to:next,heading:bearing,travel:length});distance+=length;}
    turn(next,bearing,next.heading);add('lowering',1.6,{point:next});current=next;
  }
  function sample(time,out={}){
    const clock=((time+phaseOffset)%duration+duration)%duration,stage=stages.find(s=>clock<s.end)||stages[0],t=clock-stage.start,d=stage.end-stage.start,f=t/d;
    let point=stage.point,graze=0,blend=0,speed=0,gaitDistance=stage.distance;
    if(stage.kind==='walking'){
      const ramp=.8,total=d-ramp,travel=t<ramp?t*t/(2*ramp):t>d-ramp?total-(d-t)**2/(2*ramp):t-ramp/2;
      const u=travel/total;point={x:THREE.MathUtils.lerp(stage.from.x,stage.to.x,u),z:THREE.MathUtils.lerp(stage.from.z,stage.to.z,u),heading:stage.heading};
      speed=stage.travel/total*Math.min(1,t/ramp,(d-t)/ramp);blend=THREE.MathUtils.smoothstep(speed,0,.35);gaitDistance+=stage.travel*u;
    }else if(stage.kind==='turning'){
      const u=THREE.MathUtils.smoothstep(f,0,1);point={...point,heading:THREE.MathUtils.lerp(stage.from,stage.to,u)};
      blend=.48*Math.sin(Math.PI*f);gaitDistance+=stage.travel*u;
    }else if(stage.kind==='raising')graze=1-THREE.MathUtils.smoothstep(f,0,1);
    else if(stage.kind==='lowering')graze=THREE.MathUtils.smoothstep(f,0,1);
    else graze=1-THREE.MathUtils.smoothstep(t,10,11.5)*(1-THREE.MathUtils.smoothstep(t,13.5,15));
    return Object.assign(out,{x:point.x,z:point.z,heading:point.heading,phase:stage.kind==='grazing'&&graze<.1?'looking':stage.kind,graze,walkBlend:blend,speed,gaitDistance});
  }
  return {stops,stages,duration,sample,bounds:{x,z,radius},lineSafe};
}
