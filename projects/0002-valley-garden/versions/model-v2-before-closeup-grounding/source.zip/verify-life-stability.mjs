// Exercise actual skeletal tracks across several turns and proximity stops.
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import * as THREE from 'three';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
import { loadValleyLife,createValleyLife } from './valley-life.js';
import { heightAt } from './terrain.js';

GLTFLoader.prototype.loadAsync=async function(url){
  this.register(()=>({name:'CPUCharacterInspection',loadTexture:async()=>new THREE.Texture()}));
  const b=await readFile(new URL(url));return this.parseAsync(b.buffer.slice(b.byteOffset,b.byteOffset+b.byteLength),new URL('.',url).href);
};
const assets=await loadValleyLife({capabilities:{getMaxAnisotropy:()=>8}});
assets.gardener.scene.traverse(o=>{
  if(!o.isMesh)return;
  assert(!o.castShadow&&o.receiveShadow,'The resident must receive world shade without entering the cached world shadow map');
  assert(!o.frustumCulled,'A fixed rest-pose bound can cull the animated resident');
});
const life=createValleyLife(new THREE.Scene(),assets,{heightAt,walkHeight:heightAt});
const camera=new THREE.PerspectiveCamera();camera.position.set(10,3,15);
const bones=[];life.gardener.traverse(o=>{if(o.isBone)bones.push(o);});
let previous=bones.map(b=>b.quaternion.clone()),maxStep=0;
for(let frame=0;frame<3200;frame++){
  life.update(1/60,frame/60,camera);
  bones.forEach((bone,i)=>{maxStep=Math.max(maxStep,bone.quaternion.angleTo(previous[i]));previous[i].copy(bone.quaternion);});
}
assert(maxStep<.12,`A turn abruptly changed a limb by ${maxStep} radians in one frame`);
const root=life.gardener.position.clone();camera.position.set(root.x,root.y+1.7,root.z+1.5);
for(let i=0;i<180;i++)life.update(1/60,54+i/60,camera);
assert(life.gardener.position.distanceTo(root)<.001,'The resident did not stop near the visitor');
previous=bones.map(b=>b.quaternion.clone());for(let i=0;i<60;i++)life.update(1/60,57+i/60,camera);
assert(bones.every((b,i)=>b.quaternion.angleTo(previous[i])<.001),'A paused resident still changes pose');
// The hysteresis band keeps tiny visitor movements from toggling the gait.
for(let i=0;i<40;i++){camera.position.z=root.z+1.8+(i%2?.015:-.015);life.update(1/60,58+i/60,camera);}
assert(life.gardener.position.distanceTo(root)<.001,'The pause threshold chatters at its boundary');
life.setQuality(false);for(let i=0;i<60;i++)life.update(1/60,60+i/60,camera);
life.setQuality(true);assert(life.gardener.visible,'Quality switching hid a nearby resident');
console.log(`OK: resident pose continuity, stable proximity stop and world-shadow separation; largest limb step ${(maxStep*180/Math.PI).toFixed(2)} degrees`);
