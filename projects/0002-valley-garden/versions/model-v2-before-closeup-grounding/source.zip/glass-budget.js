import * as THREE from 'three';

/** Small distant panes keep real transparency without a whole-scene transmission prepass. */
export function createGlassBudget(scene){
  const entries=[],substitutes=new Map(),world=new THREE.Vector3();let high=true,cheapCount=0;
  function cheap(material){
    if(!substitutes.has(material))substitutes.set(material,new THREE.MeshPhysicalMaterial({name:material.name+' · distant pane',color:material.color,roughness:.13,metalness:0,transparent:true,opacity:.26,depthWrite:false,side:THREE.FrontSide,envMapIntensity:material.envMapIntensity,specularIntensity:.75}));
    return substitutes.get(material);
  }
  scene.traverse(object=>{
    if(!object.isMesh)return;const original=object.material,parts=Array.isArray(original)?original:[original];
    if(!parts.some(m=>m.transmission>0))return;
    const distant=Array.isArray(original)?parts.map(m=>m.transmission>0?cheap(m):m):cheap(original);
    entries.push({object,original,distant,physical:true});
  });
  function update(camera){
    cheapCount=0;
    for(const e of entries){
      e.object.getWorldPosition(world);const distance=world.distanceTo(camera.position),near=high?20:16,far=near+5;
      if(e.physical&&distance>far){e.object.material=e.distant;e.physical=false;}
      else if(!e.physical&&distance<near){e.object.material=e.original;e.physical=true;}
      if(!e.physical)cheapCount++;
    }
  }
  return {update,get cheapCount(){return cheapCount;},get count(){return entries.length;},physical(){for(const e of entries){e.object.material=e.original;e.physical=true;}cheapCount=0;},setQuality(value){high=value;},dispose(){for(const e of entries)e.object.material=e.original;for(const material of substitutes.values())material.dispose();}};
}
